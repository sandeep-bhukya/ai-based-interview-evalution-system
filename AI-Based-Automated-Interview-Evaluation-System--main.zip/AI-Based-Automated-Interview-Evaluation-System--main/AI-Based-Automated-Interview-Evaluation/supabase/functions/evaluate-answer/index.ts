import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

interface EvaluationRequest {
  question: string;
  answer: string;
  questionCategory: string;
  jobRole: string;
  resumeContext?: string;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { question, answer, questionCategory, jobRole, resumeContext } = await req.json() as EvaluationRequest;
    
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    const systemPrompt = `You are an experienced Indian HR interviewer evaluating a candidate's answer. 
Your evaluation style should be warm but professional, like a real Indian HR reviewer.

Evaluate the answer based on:
1. Content relevance - Does it answer the question appropriately?
2. Clarity - Is the answer clear and well-structured?
3. Confidence - Does the answer show confidence (based on answer structure and content)?
4. Answer structure - Is it organized with proper flow?

DO NOT judge strict English fluency. Focus on content quality.

Job Role: ${jobRole}
Question Category: ${questionCategory}
${resumeContext ? `Resume Context: ${resumeContext}` : ''}`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: systemPrompt },
          { 
            role: "user", 
            content: `Question: "${question}"

Candidate's Answer: "${answer}"

Please evaluate this answer and provide your assessment.` 
          }
        ],
        tools: [
          {
            type: "function",
            function: {
              name: "evaluate_answer",
              description: "Evaluate the interview answer and return structured feedback",
              parameters: {
                type: "object",
                properties: {
                  score: {
                    type: "number",
                    description: "Score from 0-10 for the answer quality"
                  },
                  strengths: {
                    type: "array",
                    items: { type: "string" },
                    description: "List of 2-3 strengths in the answer"
                  },
                  weaknesses: {
                    type: "array",
                    items: { type: "string" },
                    description: "List of 2-3 areas for improvement"
                  },
                  missingPoints: {
                    type: "array",
                    items: { type: "string" },
                    description: "Key points that were missed in the answer"
                  },
                  feedback: {
                    type: "string",
                    description: "A brief HR-style feedback in simple language (2-3 sentences)"
                  }
                },
                required: ["score", "strengths", "weaknesses", "missingPoints", "feedback"],
                additionalProperties: false
              }
            }
          }
        ],
        tool_choice: { type: "function", function: { name: "evaluate_answer" } }
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limits exceeded, please try again later." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "Payment required, please add credits." }), {
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const errorText = await response.text();
      console.error("AI gateway error:", response.status, errorText);
      throw new Error(`AI gateway error: ${response.status}`);
    }

    const data = await response.json();
    console.log("AI response:", JSON.stringify(data, null, 2));
    
    // Try to get evaluation from tool call first
    const toolCall = data.choices?.[0]?.message?.tool_calls?.[0];
    
    let evaluation;
    if (toolCall?.function?.arguments) {
      evaluation = JSON.parse(toolCall.function.arguments);
    } else {
      // Fallback: try to parse from content if model didn't use tool
      const content = data.choices?.[0]?.message?.content;
      if (content) {
        console.log("No tool call, attempting to parse from content");
        // Try to extract JSON from content
        const jsonMatch = content.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
          try {
            evaluation = JSON.parse(jsonMatch[0]);
          } catch (e) {
            console.error("Failed to parse JSON from content:", e);
          }
        }
      }
      
      // If still no evaluation, provide default
      if (!evaluation) {
        console.log("Using fallback evaluation");
        evaluation = {
          score: 5,
          strengths: ["Answer was provided"],
          weaknesses: ["Could not fully evaluate the response"],
          missingPoints: [],
          feedback: "Your answer was recorded. Please try again if evaluation seems incomplete."
        };
      }
    }
    
    return new Response(JSON.stringify(evaluation), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Evaluation error:", error);
    return new Response(JSON.stringify({ 
      error: error instanceof Error ? error.message : "Evaluation failed" 
    }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
