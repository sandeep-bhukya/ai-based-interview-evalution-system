import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

interface SuggestionRequest {
  responses: Array<{
    question: string;
    answer: string;
    score: number;
    category: string;
    strengths?: string[];
    weaknesses?: string[];
  }>;
  jobRole: string;
  overallScore: number;
  resumeContext?: string;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { responses, jobRole, overallScore, resumeContext } = await req.json() as SuggestionRequest;
    
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    // Prepare summary of responses for AI
    const responseSummary = responses.map((r, i) => 
      `Q${i + 1} (${r.category}): Score ${r.score}/10
${r.weaknesses?.length ? `Weaknesses: ${r.weaknesses.join(', ')}` : ''}`
    ).join('\n');

    const systemPrompt = `You are an experienced Indian HR professional providing improvement suggestions to a job candidate.
Your tone should be encouraging, practical, and sound like a real Indian HR reviewer.
Use simple language that's easy to understand.

The candidate interviewed for: ${jobRole}
Overall Score: ${overallScore}/100
${resumeContext ? `Resume Context: ${resumeContext}` : ''}

Based on their interview performance, provide actionable suggestions for improvement.`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: systemPrompt },
          { 
            role: "user", 
            content: `Here's a summary of the candidate's interview responses:

${responseSummary}

Please provide personalized improvement suggestions for this candidate.` 
          }
        ],
        tools: [
          {
            type: "function",
            function: {
              name: "generate_suggestions",
              description: "Generate HR-style improvement suggestions",
              parameters: {
                type: "object",
                properties: {
                  suggestions: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        category: {
                          type: "string",
                          enum: ["communication", "confidence", "structure", "technical", "resume", "personality"],
                          description: "Category of improvement"
                        },
                        suggestion: {
                          type: "string",
                          description: "Specific, actionable suggestion in simple language"
                        },
                        priority: {
                          type: "number",
                          description: "Priority 1-3 (1 is highest)"
                        }
                      },
                      required: ["category", "suggestion", "priority"]
                    },
                    description: "List of 4-6 improvement suggestions"
                  },
                  overallFeedback: {
                    type: "string",
                    description: "Overall encouraging feedback (3-4 sentences) in Indian HR style"
                  }
                },
                required: ["suggestions", "overallFeedback"],
                additionalProperties: false
              }
            }
          }
        ],
        tool_choice: { type: "function", function: { name: "generate_suggestions" } }
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limits exceeded, please try again later." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "Payment required, please add credits." }), {
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const errorText = await response.text();
      console.error("AI gateway error:", response.status, errorText);
      throw new Error(`AI gateway error: ${response.status}`);
    }

    const data = await response.json();
    const toolCall = data.choices?.[0]?.message?.tool_calls?.[0];
    
    if (!toolCall?.function?.arguments) {
      throw new Error("No suggestions received");
    }

    const result = JSON.parse(toolCall.function.arguments);
    
    return new Response(JSON.stringify(result), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Suggestions error:", error);
    return new Response(JSON.stringify({ 
      error: error instanceof Error ? error.message : "Failed to generate suggestions" 
    }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
