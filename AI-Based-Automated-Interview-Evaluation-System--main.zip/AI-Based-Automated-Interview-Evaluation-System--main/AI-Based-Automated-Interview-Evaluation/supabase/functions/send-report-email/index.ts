import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { Resend } from "npm:resend@2.0.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";
import { Buffer } from "node:buffer";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

interface EmailReportData {
  userName: string;
  userEmail: string;
  jobRole: string;
  interviewType: string;
  overallScore: number;
  atsScore?: number;
  sessionId?: string | null;
  pdfBase64?: string;
  pdfFileName?: string;
  responses: Array<{
    question: string;
    answer: string;
    score: number;
    strengths?: string[];
    weaknesses?: string[];
    feedback?: string;
  }>;
  suggestions: Array<{
    category: string;
    suggestion: string;
  }>;
  overallFeedback?: string;
}

function generateEmailHTML(data: EmailReportData): string {
  const date = new Date().toLocaleDateString('en-IN', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });

  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin: 0; padding: 0; font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; background-color: #f4f7fa; line-height: 1.8;">
  <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="background-color: #f4f7fa;">
    <tr>
      <td style="padding: 40px 20px;">
        <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="600" style="margin: 0 auto; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
          
          <!-- Header -->
          <tr>
            <td style="background: linear-gradient(135deg, #3b82f6 0%, #6366f1 100%); padding: 40px 40px 30px; text-align: center;">
              <h1 style="margin: 0; color: #ffffff; font-size: 26px; font-weight: 700;">🎯 AI Interview Assessment Report</h1>
              <p style="margin: 10px 0 0; color: rgba(255,255,255,0.9); font-size: 14px;">${date}</p>
            </td>
          </tr>
          
          <!-- Body -->
          <tr>
            <td style="padding: 35px 40px;">
              <p style="margin: 0 0 20px; color: #1e293b; font-size: 16px;">Dear <strong>${data.userName}</strong>,</p>
              
              <p style="margin: 0 0 20px; color: #475569; font-size: 15px;">
                Thank you for attending the AI-based mock interview session.
              </p>
              
              <p style="margin: 0 0 20px; color: #475569; font-size: 15px;">
                We are pleased to share your interview performance report. Please find the attached assessment report for your reference.
              </p>
              
              <div style="background-color: #f8fafc; border-radius: 10px; padding: 20px 25px; margin: 25px 0;">
                <h3 style="margin: 0 0 15px; color: #1e293b; font-size: 15px; font-weight: 600;">The report includes:</h3>
                <ul style="margin: 0; padding: 0 0 0 20px; color: #475569; font-size: 14px;">
                  <li style="margin-bottom: 8px;">ATS Resume Score</li>
                  <li style="margin-bottom: 8px;">Overall Interview Performance Score</li>
                  <li style="margin-bottom: 8px;">Question-wise Evaluation</li>
                  <li style="margin-bottom: 8px;">Voice Clarity & Communication Analysis</li>
                  <li style="margin-bottom: 0;">Personalized Improvement Suggestions</li>
                </ul>
              </div>
              
              <!-- Quick Stats -->
              <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin: 25px 0;">
                <tr>
                  <td width="48%" style="background: linear-gradient(135deg, #eff6ff 0%, #e0e7ff 100%); border-radius: 10px; padding: 20px; text-align: center;">
                    <div style="font-size: 36px; font-weight: 700; color: #3b82f6;">${data.overallScore}%</div>
                    <div style="font-size: 13px; color: #64748b; margin-top: 5px;">Overall Score</div>
                  </td>
                  <td width="4%"></td>
                  <td width="48%" style="background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%); border-radius: 10px; padding: 20px; text-align: center;">
                    <div style="font-size: 36px; font-weight: 700; color: #22c55e;">${data.atsScore ?? 'N/A'}${data.atsScore ? '%' : ''}</div>
                    <div style="font-size: 13px; color: #64748b; margin-top: 5px;">ATS Score</div>
                  </td>
                </tr>
              </table>
              
              <p style="margin: 25px 0 20px; color: #475569; font-size: 15px;">
                We hope this detailed feedback helps you identify your strengths and areas for improvement, and supports your preparation for real-world interviews.
              </p>
              
              <p style="margin: 0 0 20px; color: #475569; font-size: 15px;">
                If you have any questions or would like to take another practice session, feel free to revisit the platform.
              </p>
              
              <p style="margin: 30px 0 5px; color: #1e293b; font-size: 15px;">Warm regards,</p>
              <p style="margin: 0; color: #3b82f6; font-size: 15px; font-weight: 600;">AI Interview Evaluation System</p>
              <p style="margin: 5px 0 0; color: #64748b; font-size: 13px;">Resume Quest Pro</p>
            </td>
          </tr>
          
          <!-- Footer -->
          <tr>
            <td style="background-color: #f8fafc; padding: 25px 40px; text-align: center; border-top: 1px solid #e2e8f0;">
              <p style="margin: 0 0 8px; color: #64748b; font-size: 13px;">
                📎 Your detailed PDF report is attached to this email.
              </p>
              <p style="margin: 0; color: #94a3b8; font-size: 11px;">
                © ${new Date().getFullYear()} AI Interview Evaluator — For interview preparation purposes only
              </p>
            </td>
          </tr>
          
        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Check for RESEND_API_KEY
    const resendApiKey = Deno.env.get("RESEND_API_KEY");
    if (!resendApiKey) {
      console.error("RESEND_API_KEY is not configured");
      throw new Error("Email service is not configured. Please contact support.");
    }

    // Verify authentication
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Missing authorization header" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: userError } = await supabase.auth.getUser(token);
    if (userError || !user?.email) {
      console.error("Auth error:", userError);
      return new Response(JSON.stringify({ error: "Invalid token" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const reportData: EmailReportData = await req.json();

    // Validate required fields
    if (!reportData.userName || !reportData.jobRole) {
      return new Response(JSON.stringify({ error: "Missing required fields" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const recipientEmail = user.email;

    // Generate email HTML
    const emailHtml = generateEmailHTML(reportData);

    // Format date for subject
    const dateStr = new Date().toLocaleDateString('en-IN', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });

    // Initialize Resend
    const resend = new Resend(resendApiKey);

    // Prepare attachments - clean base64 if it has data URI prefix
    let attachments: Array<{ filename: string; content: Buffer }> | undefined;
    if (reportData.pdfBase64) {
      let cleanBase64 = reportData.pdfBase64;
      // Remove data URI prefix if present
      if (cleanBase64.includes(',')) {
        cleanBase64 = cleanBase64.split(',')[1];
      }
      // Remove any whitespace
      cleanBase64 = cleanBase64.replace(/\s/g, '');
      
      attachments = [{
        filename: reportData.pdfFileName || `Interview-Report-${dateStr}.pdf`,
        content: Buffer.from(cleanBase64, "base64"),
      }];
    }

    // Send email
    const emailResponse = await resend.emails.send({
      from: "AI Interview Evaluator <onboarding@resend.dev>",
      to: [recipientEmail],
      subject: `Your AI Interview Assessment Report – ${dateStr}`,
      html: emailHtml,
      attachments,
    });

    console.log("Resend API response:", JSON.stringify(emailResponse));

    // Check if Resend returned an error
    if (emailResponse.error) {
      console.error("Resend error:", emailResponse.error);
      throw new Error(emailResponse.error.message || "Failed to send email via Resend");
    }

    if (!emailResponse.data?.id) {
      console.error("No email ID returned from Resend");
      throw new Error("Email service did not confirm delivery");
    }

    console.log("Email sent successfully with ID:", emailResponse.data.id);

    return new Response(JSON.stringify({ 
      success: true, 
      message: "Report sent to your email!",
      emailId: emailResponse.data.id 
    }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (error) {
    console.error("Error sending email:", error);
    return new Response(
      JSON.stringify({ 
        success: false,
        error: error instanceof Error ? error.message : "Failed to send email" 
      }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});
