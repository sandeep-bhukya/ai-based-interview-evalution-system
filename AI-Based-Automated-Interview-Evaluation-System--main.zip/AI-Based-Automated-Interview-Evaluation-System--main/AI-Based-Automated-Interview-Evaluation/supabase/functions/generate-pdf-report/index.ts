import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

interface ReportData {
  userName: string;
  userEmail: string;
  jobRole: string;
  interviewType: string;
  overallScore: number;
  atsScore?: number;
  responses: Array<{
    question: string;
    answer: string;
    score: number;
    strengths?: string[];
    weaknesses?: string[];
    feedback?: string;
  }>;
  suggestions: Array<{
    category: string;
    suggestion: string;
  }>;
  overallFeedback?: string;
}

function generatePDFContent(data: ReportData): string {
  const date = new Date().toLocaleDateString('en-IN', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });

  const getRecommendation = (score: number) => {
    if (score >= 80) return 'Strong Hire';
    if (score >= 70) return 'Hire';
    if (score >= 60) return 'Consider';
    return 'Need Improvement';
  };

  // Generate HTML content for PDF
  const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { 
      font-family: 'Helvetica', 'Arial', sans-serif; 
      line-height: 1.6; 
      color: #1e293b;
      padding: 40px;
      max-width: 800px;
      margin: 0 auto;
    }
    .header {
      text-align: center;
      border-bottom: 3px solid #3b82f6;
      padding-bottom: 20px;
      margin-bottom: 30px;
    }
    .header h1 {
      color: #3b82f6;
      font-size: 28px;
      margin-bottom: 10px;
    }
    .header p { color: #64748b; font-size: 14px; }
    .section {
      margin-bottom: 25px;
      page-break-inside: avoid;
    }
    .section-title {
      font-size: 18px;
      color: #3b82f6;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 8px;
      margin-bottom: 15px;
    }
    .score-card {
      background: linear-gradient(135deg, #eff6ff 0%, #e0e7ff 100%);
      border-radius: 12px;
      padding: 25px;
      text-align: center;
      margin-bottom: 25px;
    }
    .score-large {
      font-size: 48px;
      font-weight: bold;
      color: #3b82f6;
    }
    .recommendation {
      display: inline-block;
      padding: 6px 16px;
      border-radius: 20px;
      font-weight: bold;
      margin-top: 10px;
    }
    .recommendation.strong { background: #22c55e; color: white; }
    .recommendation.hire { background: #3b82f6; color: white; }
    .recommendation.consider { background: #f97316; color: white; }
    .recommendation.improve { background: #ef4444; color: white; }
    .info-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 15px;
      margin-bottom: 25px;
    }
    .info-item {
      background: #f8fafc;
      padding: 12px;
      border-radius: 8px;
    }
    .info-label { font-size: 12px; color: #64748b; }
    .info-value { font-weight: 600; color: #1e293b; }
    .question-card {
      border: 1px solid #e2e8f0;
      border-radius: 8px;
      padding: 15px;
      margin-bottom: 15px;
    }
    .question-header {
      display: flex;
      justify-content: space-between;
      align-items: start;
      margin-bottom: 10px;
    }
    .question-text { font-weight: 600; flex: 1; padding-right: 10px; }
    .score-badge {
      background: #3b82f6;
      color: white;
      padding: 4px 10px;
      border-radius: 12px;
      font-size: 12px;
      white-space: nowrap;
    }
    .answer { color: #475569; font-size: 14px; margin-bottom: 10px; }
    .feedback { 
      background: #fef3c7; 
      padding: 10px; 
      border-radius: 6px; 
      font-size: 13px; 
      font-style: italic;
    }
    .suggestion-item {
      display: flex;
      align-items: start;
      gap: 10px;
      padding: 10px;
      background: #f8fafc;
      border-radius: 6px;
      margin-bottom: 10px;
    }
    .category-badge {
      padding: 4px 10px;
      border-radius: 12px;
      font-size: 11px;
      font-weight: 600;
      text-transform: capitalize;
    }
    .category-communication { background: #dbeafe; color: #1d4ed8; }
    .category-confidence { background: #dcfce7; color: #15803d; }
    .category-structure { background: #f3e8ff; color: #7c3aed; }
    .category-technical { background: #ffedd5; color: #c2410c; }
    .strengths-weaknesses {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 20px;
    }
    .sw-list { list-style: none; }
    .sw-list li {
      padding: 6px 0;
      font-size: 14px;
    }
    .sw-list li::before {
      content: "•";
      margin-right: 8px;
    }
    .strengths li::before { color: #22c55e; }
    .weaknesses li::before { color: #f97316; }
    .footer {
      margin-top: 30px;
      padding-top: 20px;
      border-top: 1px solid #e2e8f0;
      text-align: center;
      color: #94a3b8;
      font-size: 12px;
    }
  </style>
</head>
<body>
  <div class="header">
    <h1>🎯 AI Interview Assessment Report</h1>
    <p>Generated on ${date}</p>
  </div>

  <div class="info-grid">
    <div class="info-item">
      <div class="info-label">Candidate Name</div>
      <div class="info-value">${data.userName}</div>
    </div>
    <div class="info-item">
      <div class="info-label">Email</div>
      <div class="info-value">${data.userEmail}</div>
    </div>
    <div class="info-item">
      <div class="info-label">Position Applied For</div>
      <div class="info-value">${data.jobRole}</div>
    </div>
    <div class="info-item">
      <div class="info-label">Interview Type</div>
      <div class="info-value">${data.interviewType === 'tech' ? 'Technical' : 'Non-Technical'}</div>
    </div>
  </div>

  <div class="score-card">
    <div class="score-large">${data.overallScore}%</div>
    <p>Overall Interview Score</p>
    <span class="recommendation ${data.overallScore >= 80 ? 'strong' : data.overallScore >= 70 ? 'hire' : data.overallScore >= 60 ? 'consider' : 'improve'}">
      ${getRecommendation(data.overallScore)}
    </span>
    ${data.atsScore ? `<p style="margin-top: 15px; font-size: 14px;">ATS Score: <strong>${data.atsScore}%</strong></p>` : ''}
  </div>

  <div class="section">
    <h2 class="section-title">📝 Question-by-Question Analysis</h2>
    ${data.responses.map((r, i) => `
      <div class="question-card">
        <div class="question-header">
          <span class="question-text">Q${i + 1}: ${r.question}</span>
          <span class="score-badge">${r.score}/5</span>
        </div>
        <div class="answer"><strong>Answer:</strong> ${r.answer.substring(0, 300)}${r.answer.length > 300 ? '...' : ''}</div>
        ${r.feedback ? `<div class="feedback"><strong>Feedback:</strong> ${r.feedback}</div>` : ''}
      </div>
    `).join('')}
  </div>

  <div class="section">
    <h2 class="section-title">💪 Strengths & Areas for Growth</h2>
    <div class="strengths-weaknesses">
      <div>
        <h4 style="color: #22c55e; margin-bottom: 10px;">✓ Strengths</h4>
        <ul class="sw-list strengths">
          ${data.responses.flatMap(r => r.strengths || []).slice(0, 4).map(s => `<li>${s}</li>`).join('') || '<li>Shows potential</li>'}
        </ul>
      </div>
      <div>
        <h4 style="color: #f97316; margin-bottom: 10px;">↑ Areas to Improve</h4>
        <ul class="sw-list weaknesses">
          ${data.responses.flatMap(r => r.weaknesses || []).slice(0, 4).map(w => `<li>${w}</li>`).join('') || '<li>Keep practicing</li>'}
        </ul>
      </div>
    </div>
  </div>

  ${data.suggestions.length > 0 ? `
  <div class="section">
    <h2 class="section-title">💡 HR Improvement Suggestions</h2>
    ${data.overallFeedback ? `<p style="margin-bottom: 15px; padding: 15px; background: #eff6ff; border-radius: 8px;">${data.overallFeedback}</p>` : ''}
    ${data.suggestions.map(s => `
      <div class="suggestion-item">
        <span class="category-badge category-${s.category}">${s.category}</span>
        <span>${s.suggestion}</span>
      </div>
    `).join('')}
  </div>
  ` : ''}

  <div class="footer">
    <p>This report was generated by AI Interview Evaluator</p>
    <p>© ${new Date().getFullYear()} - For interview preparation purposes only</p>
  </div>
</body>
</html>`;

  return html;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Get authorization header
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Initialize Supabase client with service role for storage
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Get user from token
    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: userError } = await supabase.auth.getUser(token);
    
    if (userError || !user) {
      return new Response(JSON.stringify({ error: "Invalid token" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const reportData: ReportData = await req.json();

    // Generate HTML content
    const htmlContent = generatePDFContent(reportData);

    // Create a unique filename
    const timestamp = Date.now();
    const fileName = `interview-report-${timestamp}.html`;
    const storagePath = `${user.id}/${fileName}`;

    // Upload to Supabase Storage
    const { data: uploadData, error: uploadError } = await supabase.storage
      .from("interview-reports")
      .upload(storagePath, htmlContent, {
        contentType: "text/html",
        upsert: false,
      });

    if (uploadError) {
      console.error("Storage upload error:", uploadError);
      throw new Error("Failed to upload report");
    }

    // Get signed URL for download (valid for 1 hour)
    const { data: signedUrlData, error: signedUrlError } = await supabase.storage
      .from("interview-reports")
      .createSignedUrl(storagePath, 3600); // 1 hour expiry

    if (signedUrlError) {
      console.error("Signed URL error:", signedUrlError);
      throw new Error("Failed to generate download URL");
    }

    // Return the HTML content directly for client-side PDF generation
    // and the signed URL for future downloads
    return new Response(JSON.stringify({ 
      success: true,
      htmlContent,
      downloadUrl: signedUrlData.signedUrl,
      fileName: fileName.replace('.html', '.pdf')
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (error) {
    console.error("PDF generation error:", error);
    return new Response(JSON.stringify({ 
      error: error instanceof Error ? error.message : "Failed to generate report" 
    }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
