-- Create storage bucket for interview reports
INSERT INTO storage.buckets (id, name, public, file_size_limit)
VALUES ('interview-reports', 'interview-reports', false, 10485760); -- 10MB limit

-- Policy: Users can view their own reports
CREATE POLICY "Users can view their own reports"
ON storage.objects FOR SELECT
TO authenticated
USING (
    bucket_id = 'interview-reports' 
    AND auth.uid()::text = (storage.foldername(name))[1]
);

-- Policy: Users can upload their own reports (via edge function with service role)
CREATE POLICY "Users can download their own reports"
ON storage.objects FOR SELECT
TO authenticated
USING (
    bucket_id = 'interview-reports'
    AND auth.uid()::text = (storage.foldername(name))[1]
);

-- Policy: Service role can manage all reports
CREATE POLICY "Service role can manage reports"
ON storage.objects FOR ALL
TO service_role
USING (bucket_id = 'interview-reports')
WITH CHECK (bucket_id = 'interview-reports');

-- Add reports table to track generated PDFs
CREATE TABLE public.interview_reports (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id UUID REFERENCES public.interview_sessions(id) ON DELETE CASCADE NOT NULL,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    storage_path TEXT NOT NULL,
    file_name TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on reports table
ALTER TABLE public.interview_reports ENABLE ROW LEVEL SECURITY;

-- Users can view their own reports
CREATE POLICY "Users can view their own reports table"
ON public.interview_reports FOR SELECT
TO authenticated
USING (auth.uid() = user_id);

-- Users can create their own reports
CREATE POLICY "Users can create their own reports"
ON public.interview_reports FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id);