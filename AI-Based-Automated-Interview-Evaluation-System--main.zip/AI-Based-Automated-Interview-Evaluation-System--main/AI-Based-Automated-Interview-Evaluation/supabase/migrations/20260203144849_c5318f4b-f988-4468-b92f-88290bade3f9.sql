-- Create app_role enum for user roles
CREATE TYPE public.app_role AS ENUM ('admin', 'user');

-- Create profiles table for user information
CREATE TABLE public.profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
    full_name TEXT,
    phone TEXT,
    email TEXT,
    avatar_url TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create user_roles table for role-based access
CREATE TABLE public.user_roles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    role app_role NOT NULL DEFAULT 'user',
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    UNIQUE (user_id, role)
);

-- Create interview_sessions table to store interview history
CREATE TABLE public.interview_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    interview_type TEXT NOT NULL CHECK (interview_type IN ('tech', 'non-tech')),
    job_role TEXT NOT NULL,
    resume_text TEXT,
    ats_score INTEGER CHECK (ats_score >= 0 AND ats_score <= 100),
    ats_missing_keywords TEXT[],
    overall_score INTEGER CHECK (overall_score >= 0 AND overall_score <= 100),
    status TEXT NOT NULL DEFAULT 'in_progress' CHECK (status IN ('in_progress', 'completed')),
    completed_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create interview_responses table for individual question responses
CREATE TABLE public.interview_responses (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id UUID REFERENCES public.interview_sessions(id) ON DELETE CASCADE NOT NULL,
    question_id TEXT NOT NULL,
    question_text TEXT NOT NULL,
    question_category TEXT NOT NULL,
    answer_text TEXT NOT NULL,
    score INTEGER CHECK (score >= 0 AND score <= 10),
    strengths TEXT[],
    weaknesses TEXT[],
    missing_points TEXT[],
    voice_clarity NUMERIC(3,1) CHECK (voice_clarity >= 0 AND voice_clarity <= 5),
    voice_confidence NUMERIC(3,1) CHECK (voice_confidence >= 0 AND voice_confidence <= 5),
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create interview_suggestions table for AI-generated suggestions
CREATE TABLE public.interview_suggestions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id UUID REFERENCES public.interview_sessions(id) ON DELETE CASCADE NOT NULL,
    category TEXT NOT NULL,
    suggestion TEXT NOT NULL,
    priority INTEGER DEFAULT 1,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.interview_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.interview_responses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.interview_suggestions ENABLE ROW LEVEL SECURITY;

-- Create security definer function for role checking
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id
      AND role = _role
  )
$$;

-- Profiles policies
CREATE POLICY "Users can view their own profile"
ON public.profiles FOR SELECT
TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own profile"
ON public.profiles FOR UPDATE
TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own profile"
ON public.profiles FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id);

-- User roles policies
CREATE POLICY "Users can view their own roles"
ON public.user_roles FOR SELECT
TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "Admins can manage all roles"
ON public.user_roles FOR ALL
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Interview sessions policies
CREATE POLICY "Users can view their own sessions"
ON public.interview_sessions FOR SELECT
TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own sessions"
ON public.interview_sessions FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own sessions"
ON public.interview_sessions FOR UPDATE
TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all sessions"
ON public.interview_sessions FOR SELECT
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Guest sessions (no auth required for practice)
CREATE POLICY "Allow anonymous interview sessions"
ON public.interview_sessions FOR INSERT
TO anon
WITH CHECK (user_id IS NULL);

CREATE POLICY "Allow reading anonymous sessions"
ON public.interview_sessions FOR SELECT
TO anon
USING (user_id IS NULL);

-- Interview responses policies
CREATE POLICY "Users can view responses for their sessions"
ON public.interview_responses FOR SELECT
TO authenticated
USING (
    EXISTS (
        SELECT 1 FROM public.interview_sessions
        WHERE id = interview_responses.session_id
        AND user_id = auth.uid()
    )
);

CREATE POLICY "Users can create responses for their sessions"
ON public.interview_responses FOR INSERT
TO authenticated
WITH CHECK (
    EXISTS (
        SELECT 1 FROM public.interview_sessions
        WHERE id = interview_responses.session_id
        AND user_id = auth.uid()
    )
);

CREATE POLICY "Anonymous can manage responses for anonymous sessions"
ON public.interview_responses FOR ALL
TO anon
USING (
    EXISTS (
        SELECT 1 FROM public.interview_sessions
        WHERE id = interview_responses.session_id
        AND user_id IS NULL
    )
);

CREATE POLICY "Admins can view all responses"
ON public.interview_responses FOR SELECT
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Interview suggestions policies
CREATE POLICY "Users can view suggestions for their sessions"
ON public.interview_suggestions FOR SELECT
TO authenticated
USING (
    EXISTS (
        SELECT 1 FROM public.interview_sessions
        WHERE id = interview_suggestions.session_id
        AND user_id = auth.uid()
    )
);

CREATE POLICY "Users can create suggestions for their sessions"
ON public.interview_suggestions FOR INSERT
TO authenticated
WITH CHECK (
    EXISTS (
        SELECT 1 FROM public.interview_sessions
        WHERE id = interview_suggestions.session_id
        AND user_id = auth.uid()
    )
);

CREATE POLICY "Anonymous can manage suggestions for anonymous sessions"
ON public.interview_suggestions FOR ALL
TO anon
USING (
    EXISTS (
        SELECT 1 FROM public.interview_sessions
        WHERE id = interview_suggestions.session_id
        AND user_id IS NULL
    )
);

-- Function to auto-create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
    INSERT INTO public.profiles (user_id, email, full_name)
    VALUES (
        NEW.id,
        NEW.email,
        COALESCE(NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1))
    );
    
    INSERT INTO public.user_roles (user_id, role)
    VALUES (NEW.id, 'user');
    
    RETURN NEW;
END;
$$;

-- Trigger for auto-creating profile
CREATE TRIGGER on_auth_user_created
AFTER INSERT ON auth.users
FOR EACH ROW
EXECUTE FUNCTION public.handle_new_user();

-- Function to update timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$;

-- Triggers for updating timestamps
CREATE TRIGGER update_profiles_updated_at
BEFORE UPDATE ON public.profiles
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_interview_sessions_updated_at
BEFORE UPDATE ON public.interview_sessions
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();