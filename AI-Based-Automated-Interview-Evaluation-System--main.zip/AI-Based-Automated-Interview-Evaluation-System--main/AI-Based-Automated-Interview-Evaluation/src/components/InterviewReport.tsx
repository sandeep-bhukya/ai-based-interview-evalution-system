import React, { useState, useEffect, useMemo, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  Trophy, 
  TrendingUp, 
  MessageSquare, 
  Brain, 
  Star,
  RefreshCw,
  Download,
  Loader2,
  Lightbulb,
  FileText,
  Mail
} from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { blobToBase64, elementToPdfBlob, saveElementAsPdf } from '@/lib/reportPdf';

interface InterviewReportProps {
  interviewData: {
    interviewType: 'tech' | 'non-tech' | '';
    resume: File | null;
    resumeText: string;
    jobRole: string;
    customRole: string;
    responses: Array<{ 
      question: string; 
      answer: string; 
      score: number;
      strengths?: string[];
      weaknesses?: string[];
      missingPoints?: string[];
      feedback?: string;
    }>;
  };
  onStartOver: () => void;
}

interface Suggestion {
  category: string;
  suggestion: string;
  priority: number;
}

export const InterviewReport: React.FC<InterviewReportProps> = ({
  interviewData,
  onStartOver
}) => {
  const { responses, jobRole, customRole, interviewType } = interviewData;
  const { user, profile } = useAuth();
  const { toast } = useToast();
  const roleName = jobRole || customRole;

  const reportRef = useRef<HTMLDivElement | null>(null);
  
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
  const [overallFeedback, setOverallFeedback] = useState('');
  const [isLoadingSuggestions, setIsLoadingSuggestions] = useState(true);
  const [isSendingEmail, setIsSendingEmail] = useState(false);
  const [isGeneratingPDF, setIsGeneratingPDF] = useState(false);
  const [emailSentAutomatically, setEmailSentAutomatically] = useState(false);
  const [sessionSaved, setSessionSaved] = useState(false);
  const [savedSessionId, setSavedSessionId] = useState<string | null>(null);
  
  // Calculate scores
  const totalScore = responses.reduce((sum, response) => sum + response.score, 0);
  const maxScore = responses.length * 5;
  const percentageScore = Math.round((totalScore / maxScore) * 100);
  
  // Categorize responses
  const technicalResponses = responses.filter((_, i) => i % 2 === 0);
  const hrResponses = responses.filter((_, i) => i % 2 === 1);
  
  const calculateCategoryAverage = (categoryResponses: typeof responses) => {
    if (categoryResponses.length === 0) return 0;
    return categoryResponses.reduce((sum, r) => sum + r.score, 0) / categoryResponses.length;
  };

  const technicalAverage = calculateCategoryAverage(technicalResponses);
  const behavioralAverage = calculateCategoryAverage(hrResponses);

  const pdfFileName = useMemo(() => {
    const date = new Date().toISOString().split('T')[0];
    const safeRole = (roleName || 'Interview').replace(/[^a-z0-9\-\s]/gi, '').trim().replace(/\s+/g, '-');
    return `Interview-Report-${safeRole}-${date}.pdf`;
  }, [roleName]);

  // Fetch AI suggestions
  useEffect(() => {
    const fetchSuggestions = async () => {
      setIsLoadingSuggestions(true);
      try {
        const { data, error } = await supabase.functions.invoke('generate-suggestions', {
          body: {
            responses: responses.map(r => ({
              question: r.question,
              answer: r.answer,
              score: r.score,
              category: 'general',
              strengths: r.strengths,
              weaknesses: r.weaknesses
            })),
            jobRole: roleName,
            overallScore: percentageScore,
            resumeContext: interviewData.resumeText?.substring(0, 500)
          }
        });

        if (error) throw error;

        setSuggestions(data.suggestions || []);
        setOverallFeedback(data.overallFeedback || '');
      } catch (error) {
        console.error('Error fetching suggestions:', error);
        setSuggestions([
          { category: 'structure', suggestion: 'Practice structuring your answers using the STAR method', priority: 1 },
          { category: 'confidence', suggestion: 'Work on delivering answers with more confidence', priority: 2 }
        ]);
        setOverallFeedback('Keep practicing to improve your interview skills!');
      } finally {
        setIsLoadingSuggestions(false);
      }
    };

    fetchSuggestions();
  }, [responses, roleName, percentageScore, interviewData.resumeText]);

  // Save session to database for logged-in users
  useEffect(() => {
    const saveSessionToDatabase = async () => {
      if (!user || sessionSaved || isLoadingSuggestions) return;

      try {
        // Create interview session
        const { data: sessionData, error: sessionError } = await supabase
          .from('interview_sessions')
          .insert({
            user_id: user.id,
            interview_type: interviewType,
            job_role: roleName,
            overall_score: percentageScore,
            status: 'completed',
            completed_at: new Date().toISOString(),
            resume_text: interviewData.resumeText?.substring(0, 5000) || null
          })
          .select()
          .single();

        if (sessionError) {
          console.error('Error saving session:', sessionError);
          return;
        }

        setSavedSessionId(sessionData.id);

        // Save individual responses
        const responsesToInsert = responses.map(r => ({
          session_id: sessionData.id,
          question_text: r.question,
          question_id: `q_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          question_category: 'general',
          answer_text: r.answer,
          score: r.score,
          strengths: r.strengths || [],
          weaknesses: r.weaknesses || [],
          missing_points: r.missingPoints || []
        }));

        const { error: responsesError } = await supabase
          .from('interview_responses')
          .insert(responsesToInsert);

        if (responsesError) {
          console.error('Error saving responses:', responsesError);
        }

        // Save suggestions
        if (suggestions.length > 0) {
          const suggestionsToInsert = suggestions.map((s, index) => ({
            session_id: sessionData.id,
            category: s.category,
            suggestion: s.suggestion,
            priority: s.priority || index + 1
          }));

          const { error: suggestionsError } = await supabase
            .from('interview_suggestions')
            .insert(suggestionsToInsert);

          if (suggestionsError) {
            console.error('Error saving suggestions:', suggestionsError);
          }
        }

        setSessionSaved(true);
        console.log('Interview session saved successfully');
      } catch (error) {
        console.error('Error saving session:', error);
      }
    };

    saveSessionToDatabase();
  }, [user, sessionSaved, isLoadingSuggestions, interviewType, roleName, percentageScore, responses, suggestions, interviewData.resumeText]);

  // Auto-send email report for logged-in users after suggestions load
  useEffect(() => {
    const autoSendEmail = async () => {
      if (!user || !profile || isLoadingSuggestions || emailSentAutomatically || suggestions.length === 0) {
        return;
      }

      if (!reportRef.current) return;

      try {
        const { data: { session } } = await supabase.auth.getSession();
        if (!session) return;

        // Generate PDF from the on-screen report and attach it.
        const pdfBlob = await elementToPdfBlob(reportRef.current, { filename: pdfFileName });
        const pdfBase64 = await blobToBase64(pdfBlob);

        const { data, error } = await supabase.functions.invoke('send-report-email', {
          body: {
            userName: profile?.full_name || user.email?.split('@')[0] || 'Candidate',
            userEmail: user.email || '',
            jobRole: roleName,
            interviewType,
            overallScore: percentageScore,
            responses,
            suggestions,
            overallFeedback,
            pdfBase64,
            pdfFileName,
            sessionId: savedSessionId,
          },
          headers: {
            Authorization: `Bearer ${session.access_token}`,
          },
        });

        if (error) throw error;
        if (!data?.success) throw new Error(data?.error || 'Failed to send report');

        setEmailSentAutomatically(true);
        toast({
          title: 'Report Sent! 📧',
          description: `Your PDF report was sent to ${user.email}. Please check Spam/Promotions too.`,
        });
      } catch (error) {
        console.error('Auto-send email error:', error);
        // Don't show error toast for auto-send - user can manually send
      }
    };

    autoSendEmail();
  }, [user, profile, isLoadingSuggestions, suggestions, emailSentAutomatically, roleName, interviewType, percentageScore, responses, overallFeedback, toast, pdfFileName, savedSessionId]);

  const handleDownloadPDF = async () => {
    if (!user) {
      toast({
        title: 'Sign in required',
        description: 'Please sign in to download your PDF report.',
        variant: 'destructive'
      });
      return;
    }

    setIsGeneratingPDF(true);

    try {
      if (!reportRef.current) throw new Error('Report is not ready yet');
      await saveElementAsPdf(reportRef.current, { filename: pdfFileName });

      toast({
        title: 'PDF Downloaded!',
        description: 'Your interview report has been saved.',
      });
    } catch (error) {
      console.error('PDF generation error:', error);
      toast({
        title: 'Download failed',
        description: 'Could not generate PDF. Please try again.',
        variant: 'destructive'
      });
    } finally {
      setIsGeneratingPDF(false);
    }
  };

  const handleSendEmail = async () => {
    if (!user) {
      toast({
        title: 'Sign in required',
        description: 'Please sign in to receive your report via email.',
        variant: 'destructive'
      });
      return;
    }

    setIsSendingEmail(true);

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error('No active session');

      if (!reportRef.current) throw new Error('Report is not ready yet');
      const pdfBlob = await elementToPdfBlob(reportRef.current, { filename: pdfFileName });
      const pdfBase64 = await blobToBase64(pdfBlob);

      const { data, error } = await supabase.functions.invoke('send-report-email', {
        body: {
          userName: profile?.full_name || user.email?.split('@')[0] || 'Candidate',
          userEmail: user.email || '',
          jobRole: roleName,
          interviewType,
          overallScore: percentageScore,
          responses,
          suggestions,
          overallFeedback,
          pdfBase64,
          pdfFileName,
          sessionId: savedSessionId,
        },
        headers: {
          Authorization: `Bearer ${session.access_token}`,
        },
      });

      if (error) throw error;
      if (!data?.success) throw new Error(data?.error || 'Failed to send report');

      toast({
        title: 'Email Sent! 📧',
        description: `Your PDF report has been sent to ${user.email}.`,
      });
    } catch (error) {
      console.error('Email sending error:', error);
      toast({
        title: 'Failed to send email',
        description: 'Could not send the report. Please try again.',
        variant: 'destructive'
      });
    } finally {
      setIsSendingEmail(false);
    }
  };
  
  const getRecommendation = () => {
    if (percentageScore >= 80) return 'Strong Hire';
    if (percentageScore >= 70) return 'Hire';
    if (percentageScore >= 60) return 'Consider';
    return 'Need Improvement';
  };
  
  const getRecommendationColor = () => {
    const recommendation = getRecommendation();
    switch (recommendation) {
      case 'Strong Hire': return 'bg-green-500';
      case 'Hire': return 'bg-blue-500';
      case 'Consider': return 'bg-orange-500';
      default: return 'bg-red-500';
    }
  };

  const getSuggestionCategoryColor = (category: string) => {
    switch (category) {
      case 'communication': return 'bg-blue-100 text-blue-700';
      case 'confidence': return 'bg-green-100 text-green-700';
      case 'structure': return 'bg-purple-100 text-purple-700';
      case 'technical': return 'bg-orange-100 text-orange-700';
      case 'resume': return 'bg-pink-100 text-pink-700';
      case 'personality': return 'bg-yellow-100 text-yellow-700';
      default: return 'bg-slate-100 text-slate-700';
    }
  };

  const getStrengths = () => {
    const allStrengths: string[] = [];
    responses.forEach(r => {
      if (r.strengths) allStrengths.push(...r.strengths);
    });
    const unique = [...new Set(allStrengths)].slice(0, 4);
    return unique.length > 0 ? unique : ['Shows potential for growth'];
  };

  const getAreasForImprovement = () => {
    const allWeaknesses: string[] = [];
    responses.forEach(r => {
      if (r.weaknesses) allWeaknesses.push(...r.weaknesses);
    });
    const unique = [...new Set(allWeaknesses)].slice(0, 4);
    return unique.length > 0 ? unique : ['Continue building experience'];
  };

  return (
    <div className="space-y-6">
      <div ref={reportRef} className="space-y-6">
        {/* Header */}
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-slate-800 mb-4">Interview Complete! 🎉</h2>
          <p className="text-slate-600">
            Here's your comprehensive evaluation report for the {roleName} position.
          </p>
        </div>

        {/* Overall Score Card */}
        <Card className="p-6 bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 border-0 shadow-lg">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-2xl font-bold text-slate-800">Overall Score</h3>
              <p className="text-slate-600">Based on {responses.length} interview questions</p>
            </div>
            <div className="text-right">
              <div className="text-4xl font-bold text-transparent bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text">
                {percentageScore}%
              </div>
              <Badge className={`${getRecommendationColor()} text-white`}>
                {getRecommendation()}
              </Badge>
            </div>
          </div>
          
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>Technical Skills</span>
                <span>{Math.round(technicalAverage * 20)}%</span>
              </div>
              <Progress value={technicalAverage * 20} className="h-2" />
            </div>
            
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>Communication & HR</span>
                <span>{Math.round(behavioralAverage * 20)}%</span>
              </div>
              <Progress value={behavioralAverage * 20} className="h-2" />
            </div>
          </div>
        </Card>

        {/* AI Suggestions */}
        <Card className="p-6">
          <div className="flex items-center space-x-2 mb-4">
            <Lightbulb className="w-5 h-5 text-yellow-500" />
            <h3 className="text-lg font-semibold text-slate-800">HR Improvement Suggestions</h3>
          </div>
          
          {isLoadingSuggestions ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="w-6 h-6 animate-spin text-blue-500" />
              <span className="ml-2 text-slate-600">Generating personalized suggestions...</span>
            </div>
          ) : (
            <div className="space-y-4">
              {overallFeedback && (
                <div className="bg-blue-50 rounded-lg p-4 mb-4">
                  <p className="text-slate-700">{overallFeedback}</p>
                </div>
              )}
              
              {suggestions.map((suggestion, index) => (
                <div key={index} className="flex items-start space-x-3 p-3 bg-slate-50 rounded-lg">
                  <Badge className={getSuggestionCategoryColor(suggestion.category)}>
                    {suggestion.category}
                  </Badge>
                  <p className="text-sm text-slate-700 flex-1">{suggestion.suggestion}</p>
                </div>
              ))}
            </div>
          )}
        </Card>

        {/* Detailed Breakdown */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Strengths */}
          <Card className="p-6">
            <div className="flex items-center space-x-2 mb-4">
              <Trophy className="w-5 h-5 text-green-500" />
              <h3 className="text-lg font-semibold text-slate-800">Strengths</h3>
            </div>
            <ul className="space-y-2">
              {getStrengths().map((strength, index) => (
                <li key={index} className="flex items-center space-x-2 text-green-700">
                  <Star className="w-4 h-4" />
                  <span>{strength}</span>
                </li>
              ))}
            </ul>
          </Card>

          {/* Areas for Improvement */}
          <Card className="p-6">
            <div className="flex items-center space-x-2 mb-4">
              <TrendingUp className="w-5 h-5 text-orange-500" />
              <h3 className="text-lg font-semibold text-slate-800">Areas for Growth</h3>
            </div>
            <ul className="space-y-2">
              {getAreasForImprovement().map((area, index) => (
                <li key={index} className="flex items-center space-x-2 text-orange-700">
                  <Brain className="w-4 h-4" />
                  <span>{area}</span>
                </li>
              ))}
            </ul>
          </Card>
        </div>

        {/* Question-by-Question Breakdown */}
        <Card className="p-6">
          <div className="flex items-center space-x-2 mb-4">
            <MessageSquare className="w-5 h-5 text-blue-500" />
            <h3 className="text-lg font-semibold text-slate-800">Question Analysis</h3>
          </div>
          
          <div className="space-y-4">
            {responses.map((response, index) => (
              <div key={index} className="border-l-4 border-blue-200 pl-4 py-2">
                <div className="flex justify-between items-start mb-2">
                  <p className="font-medium text-slate-800 text-sm flex-1 pr-4">
                    Q{index + 1}: {response.question}
                  </p>
                  <div className="flex items-center space-x-1 shrink-0">
                    {[...Array(5)].map((_, i) => (
                      <Star 
                        key={i} 
                        className={`w-4 h-4 ${i < response.score ? 'text-yellow-400 fill-current' : 'text-slate-300'}`} 
                      />
                    ))}
                    <span className="text-sm text-slate-600 ml-2">{response.score}/5</span>
                  </div>
                </div>
                {response.feedback && (
                  <p className="text-sm text-slate-600 italic">{response.feedback}</p>
                )}
                <p className="text-xs text-slate-400 mt-1">
                  Answer length: {response.answer.length} characters
                </p>
              </div>
            ))}
          </div>
        </Card>

        {/* Footer Message */}
        <div className="bg-slate-50 rounded-lg p-4 text-center">
          <p className="text-sm text-slate-600">
            🚀 This AI-powered interview evaluation provides insights based on your responses. 
            Consider this as one data point in your interview preparation journey!
          </p>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex flex-col sm:flex-row gap-4 pt-6">
        <Button 
          onClick={onStartOver} 
          variant="outline" 
          className="flex items-center space-x-2 flex-1"
        >
          <RefreshCw className="w-4 h-4" />
          <span>Start New Interview</span>
        </Button>
        
        {user ? (
          <>
            <Button 
              className="bg-gradient-to-r from-blue-500 to-indigo-500 hover:from-blue-600 hover:to-indigo-600 flex items-center space-x-2 flex-1"
              onClick={handleDownloadPDF}
              disabled={isGeneratingPDF || isLoadingSuggestions}
            >
              {isGeneratingPDF ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Generating PDF...</span>
                </>
              ) : (
                <>
                  <FileText className="w-4 h-4" />
                  <span>Download PDF</span>
                </>
              )}
            </Button>
            <Button 
              variant="outline"
              className="flex items-center space-x-2 flex-1 border-green-500 text-green-600 hover:bg-green-50"
              onClick={handleSendEmail}
              disabled={isSendingEmail || isLoadingSuggestions}
            >
              {isSendingEmail ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Sending...</span>
                </>
              ) : (
                <>
                  <Mail className="w-4 h-4" />
                  <span>Send to Email</span>
                </>
              )}
            </Button>
          </>
        ) : (
          <Button 
            className="bg-gradient-to-r from-blue-500 to-indigo-500 hover:from-blue-600 hover:to-indigo-600 flex items-center space-x-2 flex-1"
            onClick={() => window.print()}
          >
            <Download className="w-4 h-4" />
            <span>Print Report</span>
          </Button>
        )}
      </div>

      {/* Login prompt for guests */}
      {!user && (
        <Card className="p-4 bg-blue-50 border-blue-200">
          <p className="text-sm text-blue-700 text-center">
            🔒 <a href="/auth" className="font-medium underline">Sign in</a> to download your PDF report, save interview history, and track your progress over time.
          </p>
        </Card>
      )}

    </div>
  );
};

