import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, MessageSquare, CheckCircle, Clock, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { 
  getInterviewQuestions, 
  getCategoryColor, 
  getCategoryDisplayName,
  type InterviewQuestion 
} from '@/config/interviewQuestions';

interface InterviewSessionProps {
  resumeText: string;
  jobRole: string;
  interviewType: 'tech' | 'non-tech' | '';
  onInterviewComplete: (responses: Array<{ 
    question: string; 
    answer: string; 
    score: number;
    strengths?: string[];
    weaknesses?: string[];
    missingPoints?: string[];
    feedback?: string;
  }>) => void;
  onBack: () => void;
}

export const InterviewSession: React.FC<InterviewSessionProps> = ({
  resumeText,
  jobRole,
  interviewType,
  onInterviewComplete,
  onBack
}) => {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [currentAnswer, setCurrentAnswer] = useState('');
  const [responses, setResponses] = useState<Array<{ 
    question: string; 
    answer: string; 
    score: number;
    category: string;
    strengths?: string[];
    weaknesses?: string[];
    missingPoints?: string[];
    feedback?: string;
  }>>([]);
  const [timeLeft, setTimeLeft] = useState(180);
  const [questions, setQuestions] = useState<InterviewQuestion[]>([]);
  const [isEvaluating, setIsEvaluating] = useState(false);
  const { toast } = useToast();

  // Load fixed questions on mount
  useEffect(() => {
    const type = interviewType === 'tech' ? 'tech' : 'non-tech';
    const interviewQuestions = getInterviewQuestions(type, false);
    setQuestions(interviewQuestions);
    if (interviewQuestions.length > 0) {
      setTimeLeft(interviewQuestions[0].timeLimit);
    }
  }, [interviewType]);

  // Timer countdown
  useEffect(() => {
    if (questions.length > 0 && timeLeft > 0 && !isEvaluating) {
      const timer = setInterval(() => {
        setTimeLeft(prev => prev - 1);
      }, 1000);
      
      return () => clearInterval(timer);
    }
  }, [timeLeft, questions.length, isEvaluating]);

  // Auto-submit when time runs out
  useEffect(() => {
    if (timeLeft === 0 && questions.length > 0 && !isEvaluating) {
      handleNextQuestion();
    }
  }, [timeLeft, questions.length, isEvaluating]);

  const evaluateAnswerWithAI = async (question: string, answer: string, category: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('evaluate-answer', {
        body: {
          question,
          answer,
          questionCategory: category,
          jobRole,
          resumeContext: resumeText?.substring(0, 500) // Send first 500 chars of resume
        }
      });

      if (error) throw error;

      return {
        score: Math.round(data.score) || 5,
        strengths: data.strengths || [],
        weaknesses: data.weaknesses || [],
        missingPoints: data.missingPoints || [],
        feedback: data.feedback || ''
      };
    } catch (error) {
      console.error('AI evaluation error:', error);
      // Fallback to basic scoring
      return {
        score: evaluateAnswerBasic(answer),
        strengths: ['Answer provided'],
        weaknesses: ['Could not evaluate with AI'],
        missingPoints: [],
        feedback: 'Basic evaluation applied'
      };
    }
  };

  const evaluateAnswerBasic = (answer: string): number => {
    const answerLength = answer.trim().length;
    let score = 0;
    if (answerLength > 100) score += 4;
    else if (answerLength > 50) score += 3;
    else if (answerLength > 20) score += 2;
    else score += 1;
    
    if (answerLength > 200) score += 2;
    if (answerLength > 300) score += 2;
    
    return Math.min(score, 10);
  };

  const handleNextQuestion = async () => {
    if (isEvaluating) return;

    const currentQuestion = questions[currentQuestionIndex];
    setIsEvaluating(true);

    // Evaluate answer with AI
    const evaluation = await evaluateAnswerWithAI(
      currentQuestion.text, 
      currentAnswer || 'No response provided',
      currentQuestion.category
    );
    
    const newResponse = {
      question: currentQuestion.text,
      answer: currentAnswer || 'No response provided',
      score: evaluation.score,
      category: currentQuestion.category,
      strengths: evaluation.strengths,
      weaknesses: evaluation.weaknesses,
      missingPoints: evaluation.missingPoints,
      feedback: evaluation.feedback
    };
    
    const updatedResponses = [...responses, newResponse];
    setResponses(updatedResponses);
    setIsEvaluating(false);
    
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
      setCurrentAnswer('');
      setTimeLeft(questions[currentQuestionIndex + 1]?.timeLimit || 180);
      
      toast({
        title: "Answer submitted!",
        description: `Moving to question ${currentQuestionIndex + 2} of ${questions.length}`,
      });
    } else {
      // Convert score from 0-10 to match report expectations (0-5)
      const finalResponses = updatedResponses.map(r => ({
        ...r,
        score: Math.round(r.score / 2) // Convert 0-10 to 0-5
      }));
      onInterviewComplete(finalResponses);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getProgressPercentage = () => {
    if (questions.length === 0) return 0;
    return ((currentQuestionIndex + 1) / questions.length) * 100;
  };

  if (questions.length === 0) {
    return (
      <div className="text-center space-y-6">
        <div className="flex flex-col items-center space-y-4">
          <Loader2 className="w-12 h-12 animate-spin text-blue-500" />
          <p className="text-slate-600">Loading interview questions...</p>
        </div>
      </div>
    );
  }

  const currentQuestion = questions[currentQuestionIndex];
  const timeColor = timeLeft < 60 ? 'text-red-500' : timeLeft < 120 ? 'text-orange-500' : 'text-green-500';

  return (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-slate-800 mb-4">
          {interviewType === 'tech' ? 'Technical' : 'Non-Technical'} Interview
        </h2>
        <p className="text-slate-600">
          Question {currentQuestionIndex + 1} of {questions.length} • {jobRole}
        </p>
      </div>

      <Card className="p-4 bg-gradient-to-r from-blue-50 to-indigo-50">
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm font-medium text-slate-600">Interview Progress</span>
          <span className={`text-sm font-medium ${timeColor} flex items-center space-x-1`}>
            <Clock className="w-4 h-4" />
            <span>{formatTime(timeLeft)}</span>
          </span>
        </div>
        <Progress value={getProgressPercentage()} className="h-2" />
      </Card>

      <Card className="p-6 bg-white">
        <div className="flex items-start space-x-4 mb-6">
          <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-indigo-500 rounded-full flex items-center justify-center">
            <MessageSquare className="w-5 h-5 text-white" />
          </div>
          <div className="flex-1">
            <div className="flex items-center space-x-2 mb-2">
              <Badge className={getCategoryColor(currentQuestion.category)}>
                {getCategoryDisplayName(currentQuestion.category)}
              </Badge>
            </div>
            <h3 className="text-lg font-medium text-slate-800 leading-relaxed">
              {currentQuestion.text}
            </h3>
          </div>
        </div>

        <Textarea
          value={currentAnswer}
          onChange={(e) => setCurrentAnswer(e.target.value)}
          placeholder="Type your answer here... Be specific and provide examples from your experience."
          className="min-h-[200px] resize-none"
          autoFocus
          disabled={isEvaluating}
        />

        <div className="flex justify-between items-center mt-4 pt-4 border-t">
          <div className="text-sm text-slate-500">
            {currentAnswer.length} characters • Aim for detailed, specific answers
          </div>
          <div className="flex space-x-2">
            <Button
              variant="outline"
              onClick={handleNextQuestion}
              disabled={!currentAnswer.trim() || isEvaluating}
              className="flex items-center space-x-2"
            >
              {isEvaluating ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Evaluating...</span>
                </>
              ) : (
                <>
                  <CheckCircle className="w-4 h-4" />
                  <span>Submit Answer</span>
                </>
              )}
            </Button>
          </div>
        </div>
      </Card>

      <div className="flex justify-between pt-6">
        <Button variant="outline" onClick={onBack} className="flex items-center space-x-2">
          <ArrowLeft className="w-4 h-4" />
          <span>Back</span>
        </Button>
        
        <div className="text-sm text-slate-500">
          Press "Submit Answer" or wait for the timer to continue
        </div>
      </div>
    </div>
  );
};
