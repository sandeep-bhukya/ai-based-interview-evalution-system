
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Code, Briefcase, Palette, TrendingUp, Shield, Database } from 'lucide-react';

interface JobRoleSelectorProps {
  selectedRole: string;
  customRole: string;
  onRoleSelected: (role: string, customRole: string) => void;
  onBack: () => void;
}

const predefinedRoles = [
  { 
    id: 'frontend-developer', 
    title: 'Frontend Developer',
    icon: Code,
    skills: ['React', 'JavaScript', 'CSS', 'HTML', 'TypeScript'],
    color: 'bg-blue-500'
  },
  { 
    id: 'backend-developer', 
    title: 'Backend Developer',
    icon: Database,
    skills: ['Node.js', 'Python', 'SQL', 'API Design', 'Cloud'],
    color: 'bg-green-500'
  },
  { 
    id: 'full-stack-developer', 
    title: 'Full Stack Developer',
    icon: Code,
    skills: ['React', 'Node.js', 'Databases', 'DevOps', 'APIs'],
    color: 'bg-purple-500'
  },
  { 
    id: 'data-scientist', 
    title: 'Data Scientist',
    icon: TrendingUp,
    skills: ['Python', 'Machine Learning', 'Statistics', 'SQL', 'Visualization'],
    color: 'bg-orange-500'
  },
  { 
    id: 'product-manager', 
    title: 'Product Manager',
    icon: Briefcase,
    skills: ['Strategy', 'Analytics', 'User Research', 'Agile', 'Communication'],
    color: 'bg-indigo-500'
  },
  { 
    id: 'ui-ux-designer', 
    title: 'UI/UX Designer',
    icon: Palette,
    skills: ['Figma', 'User Research', 'Prototyping', 'Design Systems', 'Usability'],
    color: 'bg-pink-500'
  },
  { 
    id: 'devops-engineer', 
    title: 'DevOps Engineer',
    icon: Shield,
    skills: ['AWS', 'Docker', 'Kubernetes', 'CI/CD', 'Monitoring'],
    color: 'bg-teal-500'
  },
  { 
    id: 'mobile-developer', 
    title: 'Mobile Developer',
    icon: Code,
    skills: ['React Native', 'iOS', 'Android', 'Mobile UX', 'Performance'],
    color: 'bg-cyan-500'
  }
];

export const JobRoleSelector: React.FC<JobRoleSelectorProps> = ({
  selectedRole,
  customRole,
  onRoleSelected,
  onBack
}) => {
  const [localCustomRole, setLocalCustomRole] = useState(customRole);
  const [selectedRoleId, setSelectedRoleId] = useState(selectedRole);

  const handleContinue = () => {
    if (selectedRoleId === 'custom' && localCustomRole.trim()) {
      onRoleSelected('custom', localCustomRole.trim());
    } else if (selectedRoleId && selectedRoleId !== 'custom') {
      const role = predefinedRoles.find(r => r.id === selectedRoleId);
      onRoleSelected(role?.title || '', '');
    }
  };

  const canContinue = selectedRoleId && (selectedRoleId !== 'custom' || localCustomRole.trim());

  return (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-slate-800 mb-4">Select Your Target Role</h2>
        <p className="text-slate-600">
          Choose the position you're interviewing for so we can tailor questions to the role.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {predefinedRoles.map((role) => {
          const IconComponent = role.icon;
          const isSelected = selectedRoleId === role.id;
          
          return (
            <div
              key={role.id}
              className={`relative cursor-pointer rounded-xl p-6 border-2 transition-all duration-300 hover:shadow-lg ${
                isSelected 
                  ? 'border-blue-500 bg-blue-50 shadow-lg scale-105' 
                  : 'border-slate-200 bg-white hover:border-slate-300'
              }`}
              onClick={() => setSelectedRoleId(role.id)}
            >
              <div className="flex items-center space-x-3 mb-3">
                <div className={`w-10 h-10 ${role.color} rounded-lg flex items-center justify-center`}>
                  <IconComponent className="w-5 h-5 text-white" />
                </div>
                <h3 className="font-semibold text-slate-800">{role.title}</h3>
              </div>
              
              <div className="flex flex-wrap gap-1">
                {role.skills.slice(0, 3).map((skill) => (
                  <Badge key={skill} variant="secondary" className="text-xs">
                    {skill}
                  </Badge>
                ))}
                {role.skills.length > 3 && (
                  <Badge variant="outline" className="text-xs">
                    +{role.skills.length - 3} more
                  </Badge>
                )}
              </div>

              {isSelected && (
                <div className="absolute -top-2 -right-2 w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center">
                  <div className="w-2 h-2 bg-white rounded-full"></div>
                </div>
              )}
            </div>
          );
        })}

        {/* Custom Role Option */}
        <div
          className={`relative cursor-pointer rounded-xl p-6 border-2 transition-all duration-300 hover:shadow-lg ${
            selectedRoleId === 'custom' 
              ? 'border-blue-500 bg-blue-50 shadow-lg scale-105' 
              : 'border-slate-200 bg-white hover:border-slate-300'
          }`}
          onClick={() => setSelectedRoleId('custom')}
        >
          <div className="flex items-center space-x-3 mb-3">
            <div className="w-10 h-10 bg-gradient-to-br from-slate-400 to-slate-600 rounded-lg flex items-center justify-center">
              <Briefcase className="w-5 h-5 text-white" />
            </div>
            <h3 className="font-semibold text-slate-800">Custom Role</h3>
          </div>
          
          <p className="text-sm text-slate-500 mb-3">Enter your specific job title</p>
          
          {selectedRoleId === 'custom' && (
            <Input
              placeholder="e.g., Machine Learning Engineer"
              value={localCustomRole}
              onChange={(e) => setLocalCustomRole(e.target.value)}
              className="mt-2"
              autoFocus
            />
          )}

          {selectedRoleId === 'custom' && (
            <div className="absolute -top-2 -right-2 w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center">
              <div className="w-2 h-2 bg-white rounded-full"></div>
            </div>
          )}
        </div>
      </div>

      <div className="flex justify-between pt-6">
        <Button variant="outline" onClick={onBack} className="flex items-center space-x-2">
          <ArrowLeft className="w-4 h-4" />
          <span>Back</span>
        </Button>
        
        <Button 
          onClick={handleContinue} 
          disabled={!canContinue}
          className="bg-gradient-to-r from-blue-500 to-indigo-500 hover:from-blue-600 hover:to-indigo-600"
        >
          Continue to Interview
        </Button>
      </div>
    </div>
  );
};
