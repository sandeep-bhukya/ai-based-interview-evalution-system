
import React from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Code, 
  Users, 
  Brain, 
  Settings, 
  ArrowRight,
  CheckCircle
} from 'lucide-react';

interface InterviewTypeSelectorProps {
  selectedType: 'tech' | 'non-tech' | '';
  onTypeSelected: (type: 'tech' | 'non-tech') => void;
  onContinue: () => void;
}

export const InterviewTypeSelector: React.FC<InterviewTypeSelectorProps> = ({
  selectedType,
  onTypeSelected,
  onContinue
}) => {
  const interviewTypes = [
    {
      id: 'tech' as const,
      title: 'Technical Interview',
      description: 'Perfect for software engineers, developers, and IT professionals',
      icon: Code,
      features: [
        'Coding challenges and problem solving',
        'System design discussions',
        'Technology stack questions',
        'Algorithm and data structure queries',
        'Architecture and best practices'
      ],
      color: 'from-blue-500 to-indigo-500',
      bgColor: 'bg-blue-50',
      borderColor: 'border-blue-200'
    },
    {
      id: 'non-tech' as const,
      title: 'Non-Technical Interview',
      description: 'Ideal for management, sales, marketing, and other business roles',
      icon: Users,
      features: [
        'Behavioral and situational questions',
        'Leadership and teamwork scenarios',
        'Communication and presentation skills',
        'Industry-specific knowledge',
        'Problem-solving and decision making'
      ],
      color: 'from-green-500 to-emerald-500',
      bgColor: 'bg-green-50',
      borderColor: 'border-green-200'
    }
  ];

  return (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-slate-800 mb-4">
          Choose Your Interview Type
        </h2>
        <p className="text-slate-600 max-w-2xl mx-auto">
          Select the type of interview that best matches your target position. 
          This will customize the questions and evaluation criteria for your specific field.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        {interviewTypes.map((type) => {
          const Icon = type.icon;
          const isSelected = selectedType === type.id;
          
          return (
            <Card 
              key={type.id}
              className={`p-6 cursor-pointer transition-all duration-200 hover:shadow-lg ${
                isSelected 
                  ? `${type.borderColor} border-2 ${type.bgColor} ring-2 ring-offset-2 ring-blue-200` 
                  : 'border-gray-200 hover:border-gray-300'
              }`}
              onClick={() => onTypeSelected(type.id)}
            >
              <div className="flex items-start justify-between mb-4">
                <div className={`p-3 rounded-lg bg-gradient-to-r ${type.color}`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                {isSelected && (
                  <CheckCircle className="w-6 h-6 text-green-500" />
                )}
              </div>
              
              <h3 className="text-xl font-semibold text-slate-800 mb-2">
                {type.title}
              </h3>
              
              <p className="text-slate-600 text-sm mb-4">
                {type.description}
              </p>
              
              <div className="space-y-2">
                <p className="text-sm font-medium text-slate-700 mb-2">
                  Interview Focus Areas:
                </p>
                <ul className="space-y-1">
                  {type.features.map((feature, index) => (
                    <li key={index} className="flex items-center space-x-2 text-sm text-slate-600">
                      <div className="w-1.5 h-1.5 bg-slate-400 rounded-full"></div>
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
              
              {isSelected && (
                <Badge className="mt-4 bg-green-100 text-green-700 hover:bg-green-100">
                  Selected
                </Badge>
              )}
            </Card>
          );
        })}
      </div>

      {/* Additional Information */}
      <Card className="p-6 bg-gradient-to-r from-amber-50 to-orange-50 border-amber-200">
        <div className="flex items-start space-x-3">
          <Brain className="w-5 h-5 text-amber-600 mt-0.5" />
          <div>
            <h4 className="font-semibold text-amber-800 mb-2">AI-Powered Evaluation</h4>
            <p className="text-sm text-amber-700">
              Our AI will adapt the interview questions, evaluation criteria, and feedback 
              recommendations based on your selected interview type to provide the most 
              relevant and actionable insights.
            </p>
          </div>
        </div>
      </Card>

      {/* Settings Preview */}
      {selectedType && (
        <Card className="p-4 bg-slate-50 border-slate-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Settings className="w-5 h-5 text-slate-500" />
              <div>
                <p className="text-sm font-medium text-slate-700">
                  Selected: {interviewTypes.find(t => t.id === selectedType)?.title}
                </p>
                <p className="text-xs text-slate-500">
                  Questions and evaluation will be tailored for {selectedType} roles
                </p>
              </div>
            </div>
            <ArrowRight className="w-4 h-4 text-slate-400" />
          </div>
        </Card>
      )}

      {/* Continue Button */}
      <div className="flex justify-center pt-6">
        <Button
          onClick={onContinue}
          disabled={!selectedType}
          className="bg-gradient-to-r from-blue-500 to-indigo-500 hover:from-blue-600 hover:to-indigo-600 px-8 py-3 text-lg"
        >
          Continue to Resume Upload
          <ArrowRight className="w-5 h-5 ml-2" />
        </Button>
      </div>
    </div>
  );
};
