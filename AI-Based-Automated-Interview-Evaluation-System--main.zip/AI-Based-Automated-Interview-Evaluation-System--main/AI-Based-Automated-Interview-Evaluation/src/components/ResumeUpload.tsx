
import React, { useCallback, useState } from 'react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { Upload, FileText, CheckCircle } from 'lucide-react';

interface ResumeUploadProps {
  onResumeUploaded: (file: File, extractedText: string) => void;
}

export const ResumeUpload: React.FC<ResumeUploadProps> = ({ onResumeUploaded }) => {
  const [isDragOver, setIsDragOver] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();

  const extractTextFromFile = async (file: File): Promise<string> => {
    // Simulate resume parsing - in a real app, you'd send this to a backend service
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const mockResumeText = `
John Doe
Software Engineer | 5 years experience
Skills: JavaScript, React, Node.js, Python, AWS, Docker
Experience:
- Senior Frontend Developer at TechCorp (2021-2024)
- Full Stack Developer at StartupXYZ (2019-2021)
Education: BS Computer Science, University of Technology
Projects: E-commerce platform, Real-time chat application, ML recommendation system
`;
    return mockResumeText;
  };

  const handleFileUpload = async (file: File) => {
    if (!file) return;

    // Validate file type
    const allowedTypes = ['application/pdf', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'text/plain'];
    if (!allowedTypes.includes(file.type)) {
      toast({
        title: "Invalid file type",
        description: "Please upload a PDF, DOCX, or TXT file",
        variant: "destructive"
      });
      return;
    }

    // Validate file size (5MB max)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "Please upload a file smaller than 5MB",
        variant: "destructive"
      });
      return;
    }

    setIsProcessing(true);
    
    try {
      const extractedText = await extractTextFromFile(file);
      onResumeUploaded(file, extractedText);
      
      toast({
        title: "Resume uploaded successfully!",
        description: "We've extracted your information and are ready to proceed.",
      });
    } catch (error) {
      toast({
        title: "Upload failed",
        description: "There was an error processing your resume. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const onDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      handleFileUpload(files[0]);
    }
  }, []);

  const onDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  }, []);

  const onDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  }, []);

  const onFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleFileUpload(file);
    }
  };

  return (
    <div className="text-center space-y-6">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-slate-800 mb-4">Upload Your Resume</h2>
        <p className="text-slate-600">
          Share your resume so our AI can understand your background and create personalized interview questions.
        </p>
      </div>

      <div
        className={`relative border-2 border-dashed rounded-xl p-12 transition-all duration-300 ${
          isDragOver 
            ? 'border-blue-400 bg-blue-50 scale-105' 
            : isProcessing
              ? 'border-green-300 bg-green-50'
              : 'border-slate-300 bg-slate-50 hover:border-slate-400 hover:bg-slate-100'
        }`}
        onDrop={onDrop}
        onDragOver={onDragOver}
        onDragLeave={onDragLeave}
      >
        <input
          type="file"
          id="resume-upload"
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
          accept=".pdf,.docx,.txt"
          onChange={onFileSelect}
          disabled={isProcessing}
        />

        <div className="flex flex-col items-center space-y-4">
          {isProcessing ? (
            <>
              <div className="animate-spin rounded-full h-12 w-12 border-4 border-green-500 border-t-transparent"></div>
              <p className="text-green-600 font-medium">Processing your resume...</p>
              <p className="text-sm text-slate-500">Extracting skills, experience, and education</p>
            </>
          ) : (
            <>
              <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-indigo-500 rounded-full flex items-center justify-center">
                <Upload className="w-8 h-8 text-white" />
              </div>
              <div>
                <p className="text-lg font-medium text-slate-700 mb-2">
                  {isDragOver ? 'Drop your resume here' : 'Drag & drop your resume'}
                </p>
                <p className="text-sm text-slate-500">or click to browse files</p>
              </div>
              <div className="flex items-center space-x-4 text-xs text-slate-400">
                <span className="flex items-center space-x-1">
                  <FileText className="w-4 h-4" />
                  <span>PDF, DOCX, TXT</span>
                </span>
                <span>•</span>
                <span>Max 5MB</span>
              </div>
            </>
          )}
        </div>
      </div>

      <div className="bg-blue-50 rounded-lg p-4 text-sm text-blue-700">
        <p className="font-medium mb-1">🔒 Your privacy matters</p>
        <p>Your resume is processed securely and never stored permanently. We only extract relevant information for the interview.</p>
      </div>
    </div>
  );
};
