import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { 
  ArrowLeft, 
  Mic, 
  MicOff, 
  Volume2, 
  Brain,
  Clock,
  Loader2
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useVoiceInteraction } from '@/hooks/useVoiceInteraction';
import { supabase } from '@/integrations/supabase/client';
import { 
  getInterviewQuestions, 
  getCategoryColor, 
  getCategoryDisplayName,
  type InterviewQuestion 
} from '@/config/interviewQuestions';

interface VoiceInterviewSessionProps {
  resumeText: string;
  jobRole: string;
  interviewType: 'tech' | 'non-tech' | '';
  onInterviewComplete: (responses: Array<{ 
    question: string; 
    answer: string; 
    score: number;
    voiceAnalysis?: {
      clarity: number;
      pace: number;
      confidence: number;
      fillerWords: number;
    };
  }>) => void;
  onBack: () => void;
}

export const VoiceInterviewSession: React.FC<VoiceInterviewSessionProps> = ({
  resumeText,
  jobRole,
  interviewType,
  onInterviewComplete,
  onBack
}) => {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [responses, setResponses] = useState<Array<any>>([]);
  const [timeLeft, setTimeLeft] = useState(120);
  const [questions, setQuestions] = useState<InterviewQuestion[]>([]);
  const [interviewPhase, setInterviewPhase] = useState<'setup' | 'question' | 'listening' | 'processing'>('setup');
  const [setupComplete, setSetupComplete] = useState(false);
  const [hasSpokenAnswer, setHasSpokenAnswer] = useState(false);
  const [isEvaluating, setIsEvaluating] = useState(false);
  
  const { toast } = useToast();
  const voice = useVoiceInteraction();

  // Load fixed questions on mount
  useEffect(() => {
    const type = interviewType === 'tech' ? 'tech' : 'non-tech';
    const interviewQuestions = getInterviewQuestions(type, false);
    setQuestions(interviewQuestions);
  }, [interviewType]);

  useEffect(() => {
    if (voice.transcript && voice.transcript.trim().length > 10) {
      setHasSpokenAnswer(true);
    }
  }, [voice.transcript]);

  useEffect(() => {
    if (interviewPhase === 'listening' && timeLeft > 0) {
      const timer = setInterval(() => {
        setTimeLeft(prev => prev - 1);
      }, 1000);
      
      return () => clearInterval(timer);
    }
  }, [timeLeft, interviewPhase]);

  useEffect(() => {
    if (timeLeft === 0 && interviewPhase === 'listening') {
      handleSubmitAnswer();
    }
  }, [timeLeft, interviewPhase]);

  const handleSetupComplete = async () => {
    try {
      setSetupComplete(true);
      setInterviewPhase('question');
      
      const firstQuestion = questions[0];
      if (firstQuestion) {
        const interviewTypeText = interviewType === 'tech' ? 'technical' : 'non-technical';
        await voice.speak(`Hello! Welcome to your ${interviewTypeText} interview. Let's begin. Here's your first question: ${firstQuestion.text}`);
        
        setInterviewPhase('listening');
        setTimeLeft(firstQuestion.timeLimit);
        voice.startListening();
      }
    } catch (error) {
      console.error('Setup error:', error);
      toast({
        title: "Setup Error",
        description: "Failed to initialize. Please ensure microphone permissions are granted and try again.",
        variant: "destructive"
      });
    }
  };

  const analyzeVoiceResponse = (transcript: string) => {
    const words = transcript.trim().split(/\s+/);
    const fillerWords = ['um', 'uh', 'like', 'you know', 'basically', 'actually'];
    const fillerCount = words.filter(word => fillerWords.includes(word.toLowerCase())).length;
    
    return {
      clarity: Math.min(words.length / 50, 1) * 5,
      pace: Math.random() * 2 + 3,
      confidence: Math.min(words.length / 30, 1) * 5,
      fillerWords: Math.min(fillerCount / words.length * 100, 5)
    };
  };

  const evaluateAnswerWithAI = async (question: string, answer: string, category: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('evaluate-answer', {
        body: {
          question,
          answer,
          questionCategory: category,
          jobRole,
          resumeContext: resumeText?.substring(0, 500)
        }
      });

      if (error) throw error;

      return {
        score: Math.round(data.score) || 5,
        strengths: data.strengths || [],
        weaknesses: data.weaknesses || [],
        missingPoints: data.missingPoints || [],
        feedback: data.feedback || ''
      };
    } catch (error) {
      console.error('AI evaluation error:', error);
      return {
        score: 5,
        strengths: ['Answer provided'],
        weaknesses: ['Could not evaluate with AI'],
        missingPoints: [],
        feedback: 'Basic evaluation applied'
      };
    }
  };

  const handleSubmitAnswer = async () => {
    if (interviewPhase !== 'listening') return;
    
    setInterviewPhase('processing');
    setIsEvaluating(true);
    voice.stopListening();
    
    const currentQuestion = questions[currentQuestionIndex];
    const transcript = voice.transcript || "No response provided";
    
    const voiceAnalysis = analyzeVoiceResponse(transcript);
    
    // Get AI evaluation
    const evaluation = await evaluateAnswerWithAI(
      currentQuestion.text,
      transcript,
      currentQuestion.category
    );
    
    const newResponse = {
      question: currentQuestion.text,
      answer: transcript,
      score: Math.round(evaluation.score / 2), // Convert 0-10 to 0-5
      category: currentQuestion.category,
      voiceAnalysis,
      strengths: evaluation.strengths,
      weaknesses: evaluation.weaknesses
    };
    
    const updatedResponses = [...responses, newResponse];
    setResponses(updatedResponses);
    
    voice.clearTranscript();
    setHasSpokenAnswer(false);
    setIsEvaluating(false);
    
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
      setInterviewPhase('question');
      
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const nextQuestion = questions[currentQuestionIndex + 1];
      let introText = "Thank you for your answer. Here's your next question: ";
      
      if (nextQuestion.category !== questions[currentQuestionIndex].category) {
        introText = `Great! Now let's move on to ${getCategoryDisplayName(nextQuestion.category)} questions. `;
      }
      
      await voice.speak(`${introText}${nextQuestion.text}`);
      
      setInterviewPhase('listening');
      setTimeLeft(nextQuestion.timeLimit);
      voice.startListening();
    } else {
      await voice.speak("Thank you for completing the interview. We're now generating your detailed report.");
      onInterviewComplete(updatedResponses);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getProgressPercentage = () => {
    if (questions.length === 0) return 0;
    return ((currentQuestionIndex + 1) / questions.length) * 100;
  };

  if (questions.length === 0) {
    return (
      <div className="text-center space-y-6">
        <div className="flex flex-col items-center space-y-4">
          <Loader2 className="w-12 h-12 animate-spin text-blue-500" />
          <p className="text-slate-600">Loading interview questions...</p>
        </div>
      </div>
    );
  }

  if (!setupComplete) {
    return (
      <div className="space-y-6">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-slate-800 mb-4">Voice Interview Setup</h2>
          <p className="text-slate-600">
            Let's set up your microphone for the {interviewType === 'tech' ? 'technical' : 'non-technical'} voice interview experience.
          </p>
        </div>

        <Card className="p-6">
          <div className="space-y-6">
            {/* Voice Setup */}
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <Mic className="w-5 h-5 text-green-500" />
                <h3 className="font-semibold">Voice Setup</h3>
              </div>
              
              <div className="bg-slate-50 rounded-lg p-6">
                <div className="flex items-center justify-between mb-4">
                  <span className="text-sm font-medium">Voice Support</span>
                  <Badge variant={voice.isSupported ? "default" : "destructive"}>
                    {voice.isSupported ? "Supported" : "Not Supported"}
                  </Badge>
                </div>
                
                <div className="space-y-3">
                  <div className="flex items-center space-x-2">
                    <Volume2 className="w-4 h-4 text-blue-500" />
                    <span className="text-sm">Text-to-Speech: Ready</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Mic className="w-4 h-4 text-green-500" />
                    <span className="text-sm">Speech Recognition: Ready</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Brain className="w-4 h-4 text-purple-500" />
                    <span className="text-sm">AI Evaluation: Ready</span>
                  </div>
                </div>
              </div>

              <div className="bg-blue-50 rounded-lg p-4 text-sm text-blue-700">
                <p><strong>Note:</strong> This interview uses voice only. No webcam or video recording.</p>
              </div>
            </div>
          </div>

          <div className="mt-6 flex justify-between">
            <Button variant="outline" onClick={onBack}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
            <Button 
              onClick={handleSetupComplete}
              disabled={!voice.isSupported}
              className="bg-gradient-to-r from-blue-500 to-indigo-500 hover:from-blue-600 hover:to-indigo-600"
            >
              Start Voice Interview
            </Button>
          </div>
        </Card>
      </div>
    );
  }

  const currentQuestion = questions[currentQuestionIndex];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-slate-800 mb-4">
          {interviewType === 'tech' ? 'Technical' : 'Non-Technical'} Voice Interview
        </h2>
        <p className="text-slate-600">
          Question {currentQuestionIndex + 1} of {questions.length} • {jobRole}
        </p>
      </div>

      {/* Progress */}
      <Card className="p-4 bg-gradient-to-r from-blue-50 to-indigo-50">
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm font-medium text-slate-600">Interview Progress</span>
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-1">
              <Clock className="w-4 h-4 text-blue-500" />
              <span className={`text-sm font-medium ${timeLeft < 30 ? 'text-red-500' : ''}`}>
                {formatTime(timeLeft)}
              </span>
            </div>
          </div>
        </div>
        <Progress value={getProgressPercentage()} className="h-2" />
      </Card>

      {/* Question Display */}
      <Card className="p-6">
        <div className="flex items-start space-x-4 mb-6">
          <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-indigo-500 rounded-full flex items-center justify-center">
            <Brain className="w-6 h-6 text-white" />
          </div>
          <div className="flex-1">
            <div className="flex items-center space-x-2 mb-2">
              <Badge className={getCategoryColor(currentQuestion.category)}>
                {getCategoryDisplayName(currentQuestion.category)}
              </Badge>
            </div>
            <h3 className="text-xl font-medium text-slate-800">
              {currentQuestion.text}
            </h3>
          </div>
        </div>

        {/* Voice Input Display */}
        <div className="bg-slate-50 rounded-lg p-4 min-h-[150px]">
          <div className="flex items-center space-x-2 mb-3">
            {voice.isListening ? (
              <>
                <Mic className="w-5 h-5 text-red-500 animate-pulse" />
                <span className="text-sm text-red-600 font-medium">Listening...</span>
              </>
            ) : (
              <>
                <MicOff className="w-5 h-5 text-slate-400" />
                <span className="text-sm text-slate-500">Microphone inactive</span>
              </>
            )}
          </div>
          
          <div className="text-slate-700">
            {voice.transcript || (
              <span className="text-slate-400 italic">
                {interviewPhase === 'listening' 
                  ? "Start speaking your answer..." 
                  : "Waiting..."}
              </span>
            )}
          </div>
        </div>

        {/* Controls */}
        <div className="flex justify-between items-center mt-4 pt-4 border-t">
          <div className="text-sm text-slate-500">
            {voice.transcript ? `${voice.transcript.split(' ').length} words` : 'Speak clearly into your microphone'}
          </div>
          
          <div className="flex space-x-2">
            <Button
              onClick={handleSubmitAnswer}
              disabled={!hasSpokenAnswer || isEvaluating}
              className="flex items-center space-x-2"
            >
              {isEvaluating ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Evaluating...</span>
                </>
              ) : (
                <span>Submit Answer</span>
              )}
            </Button>
          </div>
        </div>
      </Card>

      {/* Phase indicator */}
      {interviewPhase === 'processing' && (
        <Card className="p-4 bg-blue-50">
          <div className="flex items-center justify-center space-x-3">
            <Loader2 className="w-5 h-5 animate-spin text-blue-500" />
            <span className="text-blue-700">Processing your answer with AI...</span>
          </div>
        </Card>
      )}

      {/* Back button */}
      <div className="flex justify-start">
        <Button variant="outline" onClick={onBack}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Exit Interview
        </Button>
      </div>
    </div>
  );
};
