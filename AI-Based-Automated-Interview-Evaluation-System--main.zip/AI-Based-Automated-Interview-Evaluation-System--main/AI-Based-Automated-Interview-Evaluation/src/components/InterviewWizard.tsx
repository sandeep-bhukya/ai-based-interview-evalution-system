import React, { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { ResumeUpload } from '@/components/ResumeUpload';
import { JobRoleSelector } from '@/components/JobRoleSelector';
import { InterviewSession } from '@/components/InterviewSession';
import { VoiceInterviewSession } from '@/components/VoiceInterviewSession';
import { InterviewReport } from '@/components/InterviewReport';
import { InterviewTypeSelector } from '@/components/InterviewTypeSelector';
import { CheckCircle, Upload, Target, MessageSquare, FileText, Brain, Mic, Keyboard } from 'lucide-react';

type WizardStep = 'type' | 'upload' | 'role' | 'mode' | 'interview' | 'report';

interface InterviewData {
  interviewType: 'tech' | 'non-tech' | '';
  resume: File | null;
  resumeText: string;
  jobRole: string;
  customRole: string;
  responses: Array<{ question: string; answer: string; score: number }>;
}

export const InterviewWizard = () => {
  const [currentStep, setCurrentStep] = useState<WizardStep>('type');
  const [interviewData, setInterviewData] = useState<InterviewData>({
    interviewType: '',
    resume: null,
    resumeText: '',
    jobRole: '',
    customRole: '',
    responses: []
  });
  const [interviewMode, setInterviewMode] = useState<'text' | 'voice'>('text');

  const steps = [
    { id: 'type', title: 'Interview Type', icon: Brain },
    { id: 'upload', title: 'Upload Resume', icon: Upload },
    { id: 'role', title: 'Select Role', icon: Target },
    { id: 'mode', title: 'Choose Mode', icon: Mic },
    { id: 'interview', title: 'AI Interview', icon: MessageSquare },
    { id: 'report', title: 'View Report', icon: FileText }
  ];

  const getStepProgress = () => {
    const stepIndex = steps.findIndex(step => step.id === currentStep);
    return ((stepIndex + 1) / steps.length) * 100;
  };

  const updateInterviewData = (updates: Partial<InterviewData>) => {
    setInterviewData(prev => ({ ...prev, ...updates }));
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 'type':
        return (
          <InterviewTypeSelector
            selectedType={interviewData.interviewType}
            onTypeSelected={(type) => updateInterviewData({ interviewType: type })}
            onContinue={() => setCurrentStep('upload')}
          />
        );
      case 'upload':
        return (
          <ResumeUpload 
            onResumeUploaded={(file, text) => {
              updateInterviewData({ resume: file, resumeText: text });
              setCurrentStep('role');
            }}
          />
        );
      case 'role':
        return (
          <JobRoleSelector 
            selectedRole={interviewData.jobRole}
            customRole={interviewData.customRole}
            onRoleSelected={(role, custom) => {
              updateInterviewData({ jobRole: role, customRole: custom });
              setCurrentStep('mode');
            }}
            onBack={() => setCurrentStep('upload')}
          />
        );
      case 'mode':
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-slate-800 mb-4">Choose Interview Mode</h2>
              <p className="text-slate-600">
                Select how you'd like to take your {interviewData.interviewType === 'tech' ? 'technical' : 'non-technical'} interview
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div 
                className={`p-6 rounded-lg border-2 cursor-pointer transition-all ${
                  interviewMode === 'text' ? 'border-blue-500 bg-blue-50' : 'border-slate-200 hover:border-slate-300'
                }`}
                onClick={() => setInterviewMode('text')}
              >
                <div className="flex items-center space-x-3 mb-3">
                  <Keyboard className="w-6 h-6 text-blue-500" />
                  <h3 className="text-lg font-semibold">Text Interview</h3>
                </div>
                <p className="text-sm text-slate-600">Type your answers. Best for detailed, well-structured responses.</p>
              </div>
              
              <div 
                className={`p-6 rounded-lg border-2 cursor-pointer transition-all ${
                  interviewMode === 'voice' ? 'border-blue-500 bg-blue-50' : 'border-slate-200 hover:border-slate-300'
                }`}
                onClick={() => setInterviewMode('voice')}
              >
                <div className="flex items-center space-x-3 mb-3">
                  <Mic className="w-6 h-6 text-green-500" />
                  <h3 className="text-lg font-semibold">Voice Interview</h3>
                </div>
                <p className="text-sm text-slate-600">Speak your answers. Simulates a real interview experience.</p>
              </div>
            </div>

            <div className="flex justify-between pt-6">
              <button 
                onClick={() => setCurrentStep('role')}
                className="px-4 py-2 text-slate-600 hover:text-slate-800"
              >
                ← Back
              </button>
              <button 
                onClick={() => setCurrentStep('interview')}
                className="px-6 py-2 bg-gradient-to-r from-blue-500 to-indigo-500 text-white rounded-lg hover:from-blue-600 hover:to-indigo-600"
              >
                Start Interview →
              </button>
            </div>
          </div>
        );
      case 'interview':
        return interviewMode === 'text' ? (
          <InterviewSession 
            resumeText={interviewData.resumeText}
            jobRole={interviewData.jobRole || interviewData.customRole}
            interviewType={interviewData.interviewType}
            onInterviewComplete={(responses) => {
              updateInterviewData({ responses });
              setCurrentStep('report');
            }}
            onBack={() => setCurrentStep('mode')}
          />
        ) : (
          <VoiceInterviewSession 
            resumeText={interviewData.resumeText}
            jobRole={interviewData.jobRole || interviewData.customRole}
            interviewType={interviewData.interviewType}
            onInterviewComplete={(responses) => {
              updateInterviewData({ responses });
              setCurrentStep('report');
            }}
            onBack={() => setCurrentStep('mode')}
          />
        );
      case 'report':
        return (
          <InterviewReport 
            interviewData={interviewData}
            onStartOver={() => {
              setInterviewData({
                interviewType: '',
                resume: null,
                resumeText: '',
                jobRole: '',
                customRole: '',
                responses: []
              });
              setCurrentStep('type');
            }}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      {/* Progress Header */}
      <Card className="mb-8 p-6 bg-white/80 backdrop-blur-sm border-0 shadow-lg">
        <div className="mb-6">
          <div className="flex justify-between items-center mb-4">
            {steps.map((step, index) => {
              const StepIcon = step.icon;
              const isActive = step.id === currentStep;
              const isCompleted = steps.findIndex(s => s.id === currentStep) > index;
              
              return (
                <div key={step.id} className="flex flex-col items-center flex-1">
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center mb-2 transition-all duration-300 ${
                    isCompleted 
                      ? 'bg-green-500 text-white' 
                      : isActive 
                        ? 'bg-blue-500 text-white shadow-lg scale-110' 
                        : 'bg-gray-200 text-gray-500'
                  }`}>
                    {isCompleted ? <CheckCircle className="w-6 h-6" /> : <StepIcon className="w-6 h-6" />}
                  </div>
                  <span className={`text-sm font-medium ${
                    isActive ? 'text-blue-600' : isCompleted ? 'text-green-600' : 'text-gray-500'
                  }`}>
                    {step.title}
                  </span>
                  {index < steps.length - 1 && (
                    <div className={`hidden sm:block w-full h-px mt-4 -mr-4 ${
                      isCompleted ? 'bg-green-500' : 'bg-gray-200'
                    }`} />
                  )}
                </div>
              );
            })}
          </div>
          <Progress value={getStepProgress()} className="h-2" />
        </div>
      </Card>

      {/* Step Content */}
      <Card className="p-8 bg-white/80 backdrop-blur-sm border-0 shadow-lg">
        {renderStepContent()}
      </Card>
    </div>
  );
};
