import React, { useEffect, useState } from 'react';
import { Navigate, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  Loader2, 
  Play, 
  Upload, 
  MessageSquare, 
  History, 
  Trophy,
  TrendingUp,
  LogOut,
  User
} from 'lucide-react';

interface InterviewSession {
  id: string;
  interview_type: string;
  job_role: string;
  overall_score: number | null;
  ats_score: number | null;
  status: string;
  completed_at: string | null;
  created_at: string;
}

const Dashboard = () => {
  const { user, profile, isLoading, signOut, isAdmin } = useAuth();
  const navigate = useNavigate();
  const [sessions, setSessions] = useState<InterviewSession[]>([]);
  const [isLoadingSessions, setIsLoadingSessions] = useState(true);

  useEffect(() => {
    if (user) {
      fetchSessions();
    }
  }, [user]);

  const fetchSessions = async () => {
    setIsLoadingSessions(true);
    try {
      const { data, error } = await supabase
        .from('interview_sessions')
        .select('*')
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false })
        .limit(10);

      if (error) {
        console.error('Error fetching sessions:', error);
      } else {
        setSessions(data || []);
      }
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setIsLoadingSessions(false);
    }
  };

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  // Redirect to auth if not logged in
  if (!isLoading && !user) {
    return <Navigate to="/auth" replace />;
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100">
        <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
      </div>
    );
  }

  // Calculate stats
  const completedSessions = sessions.filter(s => s.status === 'completed');
  const averageScore = completedSessions.length > 0
    ? Math.round(completedSessions.reduce((sum, s) => sum + (s.overall_score || 0), 0) / completedSessions.length)
    : 0;
  const latestAtsScore = sessions.find(s => s.ats_score !== null)?.ats_score || null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
            AI Interview Evaluator
          </h1>
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <User className="w-4 h-4 text-slate-500" />
              <span className="text-sm text-slate-600">
                {profile?.full_name || user?.email}
              </span>
              {isAdmin && (
                <Badge variant="secondary">Admin</Badge>
              )}
            </div>
            <Button variant="ghost" size="sm" onClick={handleSignOut}>
              <LogOut className="w-4 h-4 mr-2" />
              Sign Out
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-slate-800 mb-2">
            Welcome back, {profile?.full_name?.split(' ')[0] || 'there'}! 👋
          </h2>
          <p className="text-slate-600">
            Track your interview progress and continue improving your skills.
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Total Interviews</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-blue-600">{sessions.length}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Completed</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-600">{completedSessions.length}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Average Score</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center space-x-2">
                <div className="text-3xl font-bold text-indigo-600">{averageScore}%</div>
                <TrendingUp className="w-5 h-5 text-green-500" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardDescription>ATS Score</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-purple-600">
                {latestAtsScore !== null ? `${latestAtsScore}%` : 'N/A'}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Button 
            size="lg" 
            className="h-auto py-6 flex flex-col items-center space-y-2 bg-gradient-to-r from-blue-500 to-indigo-500 hover:from-blue-600 hover:to-indigo-600"
            onClick={() => navigate('/')}
          >
            <Play className="w-6 h-6" />
            <span>Start Interview</span>
          </Button>

          <Button 
            size="lg" 
            variant="outline"
            className="h-auto py-6 flex flex-col items-center space-y-2"
            onClick={() => navigate('/')}
          >
            <Trophy className="w-6 h-6" />
            <span>Practice Interview</span>
          </Button>

          <Button 
            size="lg" 
            variant="outline"
            className="h-auto py-6 flex flex-col items-center space-y-2"
            onClick={() => navigate('/')}
          >
            <Upload className="w-6 h-6" />
            <span>Upload Resume</span>
          </Button>

          <Button 
            size="lg" 
            variant="outline"
            className="h-auto py-6 flex flex-col items-center space-y-2"
            onClick={() => navigate('/ask-hr')}
          >
            <MessageSquare className="w-6 h-6" />
            <span>Ask HR Anything</span>
          </Button>
        </div>

        {/* Interview History */}
        <Card>
          <CardHeader>
            <div className="flex items-center space-x-2">
              <History className="w-5 h-5 text-blue-500" />
              <CardTitle>Interview History</CardTitle>
            </div>
            <CardDescription>Your recent interview sessions</CardDescription>
          </CardHeader>
          <CardContent>
            {isLoadingSessions ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="w-6 h-6 animate-spin text-blue-500" />
              </div>
            ) : sessions.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-slate-500 mb-4">No interviews yet. Start your first interview!</p>
                <Button onClick={() => navigate('/')}>
                  Start Interview
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                {sessions.map((session) => (
                  <div 
                    key={session.id}
                    role="button"
                    tabIndex={0}
                    onClick={() => navigate(`/sessions/${session.id}`)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        navigate(`/sessions/${session.id}`);
                      }
                    }}
                    className="flex items-center justify-between p-4 border rounded-lg hover:bg-slate-50 transition-colors cursor-pointer"
                  >
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-100 to-indigo-100 flex items-center justify-center">
                        <Trophy className="w-6 h-6 text-blue-500" />
                      </div>
                      <div>
                        <h4 className="font-medium text-slate-800">{session.job_role}</h4>
                        <div className="flex items-center space-x-2 text-sm text-slate-500">
                          <Badge variant="outline">
                            {session.interview_type === 'tech' ? 'Technical' : 'Non-Technical'}
                          </Badge>
                          <span>•</span>
                          <span>
                            {new Date(session.created_at).toLocaleDateString()}
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      {session.overall_score !== null ? (
                        <div className="text-right">
                          <div className="text-lg font-bold text-blue-600">
                            {session.overall_score}%
                          </div>
                          <Progress 
                            value={session.overall_score} 
                            className="w-20 h-2"
                          />
                        </div>
                      ) : (
                        <Badge variant={session.status === 'completed' ? 'default' : 'secondary'}>
                          {session.status === 'completed' ? 'Completed' : 'In Progress'}
                        </Badge>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Admin Link */}
        {isAdmin && (
          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Admin Panel</CardTitle>
              <CardDescription>Access administrative features</CardDescription>
            </CardHeader>
            <CardContent>
              <Button onClick={() => navigate('/admin')}>
                Go to Admin Panel
              </Button>
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  );
};

export default Dashboard;
