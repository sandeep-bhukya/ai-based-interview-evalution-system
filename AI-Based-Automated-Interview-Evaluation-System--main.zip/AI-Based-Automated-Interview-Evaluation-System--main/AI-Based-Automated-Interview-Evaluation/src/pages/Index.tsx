import React from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { InterviewWizard } from '@/components/InterviewWizard';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';
import { LogIn, LayoutDashboard, User } from 'lucide-react';

const Index = () => {
  const { user, profile, isLoading } = useAuth();
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
            AI Interview Evaluator
          </h1>
          <div className="flex items-center space-x-4">
            {!isLoading && (
              user ? (
                <>
                  <div className="flex items-center space-x-2 text-sm text-slate-600">
                    <User className="w-4 h-4" />
                    <span>{profile?.full_name || user.email}</span>
                  </div>
                  <Button size="sm" variant="outline" onClick={() => navigate('/dashboard')}>
                    <LayoutDashboard className="w-4 h-4 mr-2" />
                    Dashboard
                  </Button>
                </>
              ) : (
                <Button size="sm" onClick={() => navigate('/auth')}>
                  <LogIn className="w-4 h-4 mr-2" />
                  Sign In
                </Button>
              )
            )}
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent mb-4">
            AI Interview Evaluator
          </h1>
          <p className="text-xl text-slate-600 max-w-2xl mx-auto">
            Upload your resume, select your target role, and experience an AI-powered interview 
            tailored specifically to your background and career goals.
          </p>
          {!user && (
            <p className="mt-4 text-sm text-slate-500">
              <Link to="/auth" className="text-blue-600 hover:underline">Sign in</Link> to save your progress, access detailed reports, and track your improvement.
            </p>
          )}
        </div>
        <InterviewWizard />
      </div>
    </div>
  );
};

export default Index;
