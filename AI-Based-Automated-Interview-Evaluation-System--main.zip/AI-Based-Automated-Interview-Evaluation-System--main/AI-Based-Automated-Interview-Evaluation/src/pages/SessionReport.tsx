import React, { useEffect, useMemo, useRef, useState } from "react";
import { Navigate, useNavigate, useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, Mail, FileText, ArrowLeft } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { blobToBase64, elementToPdfBlob, saveElementAsPdf } from "@/lib/reportPdf";

type SessionRow = {
  id: string;
  interview_type: string;
  job_role: string;
  overall_score: number | null;
  ats_score: number | null;
  created_at: string;
  completed_at: string | null;
  status: string;
};

type ResponseRow = {
  id: string;
  question_text: string;
  answer_text: string;
  score: number | null;
  strengths: string[] | null;
  weaknesses: string[] | null;
  missing_points: string[] | null;
  created_at: string;
};

type SuggestionRow = {
  id: string;
  category: string;
  suggestion: string;
  priority: number | null;
};

export default function SessionReport() {
  const { user, profile, isLoading } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const { sessionId } = useParams();

  const reportRef = useRef<HTMLDivElement | null>(null);

  const [session, setSession] = useState<SessionRow | null>(null);
  const [responses, setResponses] = useState<ResponseRow[]>([]);
  const [suggestions, setSuggestions] = useState<SuggestionRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [downloading, setDownloading] = useState(false);

  const pdfFileName = useMemo(() => {
    const date = new Date().toISOString().split("T")[0];
    const safeRole = (session?.job_role || "Interview").replace(/[^a-z0-9\-\s]/gi, "").trim().replace(/\s+/g, "-");
    return `Interview-Report-${safeRole}-${date}.pdf`;
  }, [session?.job_role]);

  useEffect(() => {
    const run = async () => {
      if (!sessionId) return;
      setLoading(true);
      try {
        const { data: s, error: sErr } = await supabase
          .from("interview_sessions")
          .select("*")
          .eq("id", sessionId)
          .maybeSingle();

        if (sErr) throw sErr;
        if (!s) {
          setSession(null);
          return;
        }

        setSession(s as SessionRow);

        const [{ data: r, error: rErr }, { data: sug, error: sugErr }] = await Promise.all([
          supabase
            .from("interview_responses")
            .select("*")
            .eq("session_id", sessionId)
            .order("created_at", { ascending: true }),
          supabase
            .from("interview_suggestions")
            .select("*")
            .eq("session_id", sessionId)
            .order("priority", { ascending: true }),
        ]);

        if (rErr) throw rErr;
        if (sugErr) throw sugErr;

        setResponses((r || []) as ResponseRow[]);
        setSuggestions((sug || []) as SuggestionRow[]);
      } catch (e) {
        console.error(e);
        toast({
          title: "Could not load report",
          description: "Please try again.",
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    };

    run();
  }, [sessionId, toast]);

  if (!isLoading && !user) return <Navigate to="/auth" replace />;
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    );
  }

  const overallScore = session?.overall_score ?? 0;

  const handleDownload = async () => {
    if (!reportRef.current) return;
    setDownloading(true);
    try {
      await saveElementAsPdf(reportRef.current, { filename: pdfFileName });
      toast({ title: "PDF Downloaded", description: "Saved to your device." });
    } catch (e) {
      console.error(e);
      toast({ title: "Download failed", description: "Please try again.", variant: "destructive" });
    } finally {
      setDownloading(false);
    }
  };

  const handleSend = async () => {
    if (!user || !session || !reportRef.current) return;
    setSending(true);
    try {
      const { data: { session: authSession } } = await supabase.auth.getSession();
      if (!authSession) throw new Error("No active session");

      const pdfBlob = await elementToPdfBlob(reportRef.current, { filename: pdfFileName });
      const pdfBase64 = await blobToBase64(pdfBlob);

      const { data, error } = await supabase.functions.invoke("send-report-email", {
        body: {
          userName: profile?.full_name || user.email?.split("@")[0] || "Candidate",
          userEmail: user.email || "",
          jobRole: session.job_role,
          interviewType: session.interview_type,
          overallScore: overallScore,
          atsScore: session.ats_score ?? undefined,
          sessionId: session.id,
          responses: responses.map((r) => ({
            question: r.question_text,
            answer: r.answer_text,
            score: r.score ?? 0,
            strengths: r.strengths ?? undefined,
            weaknesses: r.weaknesses ?? undefined,
          })),
          suggestions: suggestions.map((s) => ({
            category: s.category,
            suggestion: s.suggestion,
          })),
          pdfBase64,
          pdfFileName,
        },
        headers: {
          Authorization: `Bearer ${authSession.access_token}`,
        },
      });

      if (error) throw error;
      if (!data?.success) throw new Error(data?.error || "Failed to send");

      toast({ title: "Email sent", description: `Sent to ${user.email}.` });
    } catch (e) {
      console.error(e);
      toast({ title: "Failed to send", description: "Please try again.", variant: "destructive" });
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100">
      <header className="bg-white/80 backdrop-blur-sm border-b sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard")}
              className="flex items-center gap-2">
              <ArrowLeft className="w-4 h-4" />
              Back
            </Button>
            <h1 className="text-lg font-semibold">Interview Report</h1>
          </div>

          <div className="flex gap-2">
            <Button variant="outline" onClick={handleSend} disabled={sending || loading}>
              {sending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Mail className="w-4 h-4" />}
              <span className="ml-2">Send PDF</span>
            </Button>
            <Button onClick={handleDownload} disabled={downloading || loading}>
              {downloading ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileText className="w-4 h-4" />}
              <span className="ml-2">Download PDF</span>
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin" />
          </div>
        ) : !session ? (
          <Card className="p-6">
            <p>Report not found.</p>
          </Card>
        ) : (
          <div ref={reportRef} className="space-y-6">
            <Card className="p-6">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <h2 className="text-2xl font-bold">{session.job_role}</h2>
                  <div className="mt-2 flex flex-wrap items-center gap-2">
                    <Badge variant="outline">{session.interview_type === "tech" ? "Technical" : "Non-Technical"}</Badge>
                    <Badge variant={session.status === "completed" ? "default" : "secondary"}>
                      {session.status}
                    </Badge>
                    <span className="text-sm text-slate-500">
                      {new Date(session.created_at).toLocaleString()}
                    </span>
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-4xl font-bold">{overallScore}%</div>
                  <div className="text-sm text-slate-600">Overall score</div>
                  <div className="mt-2 text-sm text-slate-600">
                    ATS: {session.ats_score !== null ? `${session.ats_score}%` : "N/A"}
                  </div>
                </div>
              </div>
            </Card>

            <Card className="p-6">
              <h3 className="font-semibold mb-4">Suggestions</h3>
              {suggestions.length === 0 ? (
                <p className="text-sm text-slate-600">No suggestions saved for this session.</p>
              ) : (
                <div className="space-y-3">
                  {suggestions.map((s) => (
                    <div key={s.id} className="flex items-start gap-3 bg-slate-50 rounded-lg p-3">
                      <Badge variant="outline">{s.category}</Badge>
                      <p className="text-sm text-slate-700">{s.suggestion}</p>
                    </div>
                  ))}
                </div>
              )}
            </Card>

            <Card className="p-6">
              <h3 className="font-semibold mb-4">Question Analysis</h3>
              {responses.length === 0 ? (
                <p className="text-sm text-slate-600">No answers saved for this session.</p>
              ) : (
                <div className="space-y-4">
                  {responses.map((r, idx) => (
                    <div key={r.id} className="border rounded-lg p-4">
                      <div className="flex items-start justify-between gap-4">
                        <p className="font-medium text-sm">Q{idx + 1}: {r.question_text}</p>
                        <Badge variant="secondary">{r.score ?? 0}/5</Badge>
                      </div>
                      <p className="mt-2 text-sm text-slate-700 whitespace-pre-wrap">{r.answer_text}</p>
                    </div>
                  ))}
                </div>
              )}
            </Card>
          </div>
        )}
      </main>
    </div>
  );
}
