import html2pdf from "html2pdf.js";

export type ReportPdfOptions = {
  filename: string;
};

const basePdfOptions = (filename: string) => ({
  margin: 10,
  filename,
  image: { type: "jpeg", quality: 0.98 },
  html2canvas: { scale: 2, useCORS: true },
  jsPDF: { unit: "mm", format: "a4", orientation: "portrait" },
});

export async function saveElementAsPdf(element: HTMLElement, opts: ReportPdfOptions) {
  await html2pdf().set(basePdfOptions(opts.filename)).from(element).save();
}

export async function elementToPdfBlob(element: HTMLElement, opts: ReportPdfOptions): Promise<Blob> {
  const blob = (await html2pdf()
    .set(basePdfOptions(opts.filename))
    .from(element)
    .outputPdf("blob")) as Blob;

  return blob;
}

export async function blobToBase64(blob: Blob): Promise<string> {
  return await new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("Failed to read PDF blob"));
    reader.onload = () => {
      const result = String(reader.result || "");
      // data:application/pdf;base64,AAAA...
      const base64 = result.includes(",") ? result.split(",")[1] : result;
      resolve(base64);
    };
    reader.readAsDataURL(blob);
  });
}
