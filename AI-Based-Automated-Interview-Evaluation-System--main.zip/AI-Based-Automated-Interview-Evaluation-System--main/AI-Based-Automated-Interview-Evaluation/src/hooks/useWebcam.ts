
import { useState, useEffect, useRef, useCallback } from 'react';

interface WebcamState {
  isActive: boolean;
  stream: MediaStream | null;
  error: string | null;
  isSupported: boolean;
  faceDetected: boolean;
  eyeContact: boolean;
  confidenceScore: number;
  isRecording: boolean;
  recordedBlob: Blob | null;
  recordingDuration: number;
}

interface WebcamHook extends WebcamState {
  startWebcam: () => Promise<void>;
  stopWebcam: () => void;
  startRecording: () => Promise<void>;
  stopRecording: () => Promise<void>;
  downloadRecording: () => void;
  videoRef: React.RefObject<HTMLVideoElement>;
  canvasRef: React.RefObject<HTMLCanvasElement>;
}

export const useWebcam = (): WebcamHook => {
  const [state, setState] = useState<WebcamState>({
    isActive: false,
    stream: null,
    error: null,
    isSupported: !!navigator.mediaDevices?.getUserMedia,
    faceDetected: false,
    eyeContact: false,
    confidenceScore: 0,
    isRecording: false,
    recordedBlob: null,
    recordingDuration: 0,
  });

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const analysisIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordingChunksRef = useRef<Blob[]>([]);
  const recordingTimerRef = useRef<NodeJS.Timeout | null>(null);
  const isAnalyzing = useRef(false);

  const detectFaceInImageData = useCallback((imageData: ImageData): { faceDetected: boolean; confidence: number } => {
    const data = imageData.data;
    const width = imageData.width;
    const height = imageData.height;
    
    let skinPixels = 0;
    let faceRegionPixels = 0;
    
    const centerX = width / 2;
    const centerY = height / 2;
    const faceRegionWidth = width * 0.6;
    const faceRegionHeight = height * 0.7;
    
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const i = (y * width + x) * 4;
        const r = data[i];
        const g = data[i + 1];
        const b = data[i + 2];
        
        const inFaceRegion = (
          x >= centerX - faceRegionWidth / 2 &&
          x <= centerX + faceRegionWidth / 2 &&
          y >= centerY - faceRegionHeight / 2 &&
          y <= centerY + faceRegionHeight / 2
        );
        
        if (inFaceRegion) {
          faceRegionPixels++;
          
          const isSkinTone = (
            r > 95 && g > 40 && b > 20 &&
            r > g && r > b &&
            Math.abs(r - g) > 15 &&
            Math.max(r, g, b) - Math.min(r, g, b) > 15
          );
          
          if (isSkinTone) {
            skinPixels++;
          }
        }
      }
    }
    
    const skinRatio = faceRegionPixels > 0 ? skinPixels / faceRegionPixels : 0;
    const faceDetected = skinRatio > 0.15;
    const confidence = Math.min(skinRatio * 3, 1);
    
    return { faceDetected, confidence };
  }, []);

  const analyzeFace = useCallback(() => {
    if (isAnalyzing.current) {
      return;
    }

    if (!videoRef.current || !canvasRef.current) {
      return;
    }

    const video = videoRef.current;
    const canvas = canvasRef.current;
    
    if (video.readyState !== 4 || video.videoWidth === 0 || video.videoHeight === 0) {
      return;
    }

    const ctx = canvas.getContext('2d');
    if (!ctx) {
      return;
    }

    try {
      isAnalyzing.current = true;
      
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;

      ctx.drawImage(video, 0, 0);

      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      
      const { faceDetected, confidence } = detectFaceInImageData(imageData);
      
      const eyeContact = faceDetected && Math.random() > 0.4;
      
      setState(prev => ({
        ...prev,
        faceDetected,
        eyeContact,
        confidenceScore: confidence,
      }));
    } catch (error) {
      console.error('Error during face analysis:', error);
    } finally {
      isAnalyzing.current = false;
    }
  }, [detectFaceInImageData]);

  const startWebcam = useCallback(async (): Promise<void> => {
    try {
      if (!state.isSupported) {
        throw new Error('Webcam not supported in this browser');
      }

      console.log('Requesting webcam access...');
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { 
          width: { ideal: 640 }, 
          height: { ideal: 480 },
          facingMode: 'user'
        },
        audio: false,
      });

      console.log('Webcam access granted');
      setState(prev => ({ ...prev, stream, isActive: true, error: null }));

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        
        const handleLoadedMetadata = () => {
          console.log('Video metadata loaded, starting analysis');
          analysisIntervalRef.current = setInterval(analyzeFace, 1000);
        };

        const handleCanPlay = () => {
          console.log('Video can play');
          if (videoRef.current) {
            videoRef.current.play().catch(console.error);
          }
        };

        videoRef.current.addEventListener('loadedmetadata', handleLoadedMetadata);
        videoRef.current.addEventListener('canplay', handleCanPlay);
      }
    } catch (error) {
      console.error('Webcam error:', error);
      setState(prev => ({
        ...prev,
        error: error instanceof Error ? error.message : 'Failed to access webcam',
        isActive: false,
      }));
    }
  }, [state.isSupported, analyzeFace]);

  const startRecording = useCallback(async (): Promise<void> => {
    try {
      if (!state.stream) {
        throw new Error('No webcam stream available');
      }

      console.log('Starting video recording...');
      
      // Create MediaRecorder with video stream
      const mediaRecorder = new MediaRecorder(state.stream, {
        mimeType: 'video/webm;codecs=vp8'
      });

      recordingChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          recordingChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(recordingChunksRef.current, { type: 'video/webm' });
        setState(prev => ({ ...prev, recordedBlob: blob }));
        console.log('Recording stopped, blob created:', blob.size, 'bytes');
      };

      mediaRecorder.start(1000); // Collect data every second
      mediaRecorderRef.current = mediaRecorder;

      // Start recording timer
      recordingTimerRef.current = setInterval(() => {
        setState(prev => ({ ...prev, recordingDuration: prev.recordingDuration + 1 }));
      }, 1000);

      setState(prev => ({ ...prev, isRecording: true, recordingDuration: 0 }));
      
    } catch (error) {
      console.error('Recording error:', error);
      setState(prev => ({
        ...prev,
        error: error instanceof Error ? error.message : 'Failed to start recording'
      }));
    }
  }, [state.stream]);

  const stopRecording = useCallback(async (): Promise<void> => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      console.log('Stopping video recording...');
      mediaRecorderRef.current.stop();
      mediaRecorderRef.current = null;
    }

    if (recordingTimerRef.current) {
      clearInterval(recordingTimerRef.current);
      recordingTimerRef.current = null;
    }

    setState(prev => ({ ...prev, isRecording: false }));
  }, []);

  const downloadRecording = useCallback(() => {
    if (!state.recordedBlob) {
      console.error('No recorded video available');
      return;
    }

    const url = URL.createObjectURL(state.recordedBlob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `interview-recording-${new Date().toISOString().slice(0, 19).replace(/:/g, '-')}.webm`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, [state.recordedBlob]);

  const stopWebcam = useCallback(() => {
    console.log('Stopping webcam...');
    
    // Stop recording if active
    if (state.isRecording) {
      stopRecording();
    }
    
    if (state.stream) {
      state.stream.getTracks().forEach(track => {
        track.stop();
        console.log('Stopped track:', track.kind);
      });
    }

    if (analysisIntervalRef.current) {
      clearInterval(analysisIntervalRef.current);
      analysisIntervalRef.current = null;
    }

    if (recordingTimerRef.current) {
      clearInterval(recordingTimerRef.current);
      recordingTimerRef.current = null;
    }

    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }

    setState(prev => ({
      ...prev,
      stream: null,
      isActive: false,
      faceDetected: false,
      eyeContact: false,
      confidenceScore: 0,
      isRecording: false,
      recordingDuration: 0,
    }));
  }, [state.stream, state.isRecording, stopRecording]);

  useEffect(() => {
    return () => {
      stopWebcam();
    };
  }, [stopWebcam]);

  return {
    ...state,
    startWebcam,
    stopWebcam,
    startRecording,
    stopRecording,
    downloadRecording,
    videoRef,
    canvasRef,
  };
};
