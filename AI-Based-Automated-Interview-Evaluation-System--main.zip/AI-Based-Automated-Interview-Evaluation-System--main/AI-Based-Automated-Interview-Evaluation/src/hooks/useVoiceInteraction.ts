import { useState, useEffect, useRef, useCallback } from 'react';

interface VoiceInteractionState {
  isListening: boolean;
  isSpeaking: boolean;
  transcript: string;
  isSupported: boolean;
  error: string | null;
}

interface VoiceInteractionHook extends VoiceInteractionState {
  startListening: () => void;
  stopListening: () => void;
  speak: (text: string) => Promise<void>;
  clearTranscript: () => void;
}

export const useVoiceInteraction = (): VoiceInteractionHook => {
  const [state, setState] = useState<VoiceInteractionState>({
    isListening: false,
    isSpeaking: false,
    transcript: '',
    isSupported: false,
    error: null,
  });

  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const synthRef = useRef<SpeechSynthesis | null>(null);
  const shouldBeListeningRef = useRef(false);
  const restartTimeoutRef = useRef<number | null>(null);

  useEffect(() => {
    // Check for browser support
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const isSupported = !!SpeechRecognition && !!window.speechSynthesis;
    
    setState(prev => ({ ...prev, isSupported }));

    if (isSupported) {
      const recognition = new SpeechRecognition();
      recognitionRef.current = recognition;
      synthRef.current = window.speechSynthesis;
      
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = 'en-IN'; // Indian English for better recognition
      // maxAlternatives is supported but not in TypeScript types

      recognition.onstart = () => {
        console.log('Speech recognition started');
        setState(prev => ({ ...prev, isListening: true, error: null }));
      };

      recognition.onresult = (event) => {
        let finalTranscript = '';
        let interimTranscript = '';
        
        for (let i = event.resultIndex; i < event.results.length; i++) {
          const transcript = event.results[i][0].transcript;
          if (event.results[i].isFinal) {
            finalTranscript += transcript + ' ';
          } else {
            interimTranscript += transcript;
          }
        }
        
        if (finalTranscript) {
          setState(prev => ({ 
            ...prev, 
            transcript: prev.transcript + finalTranscript 
          }));
        }
      };

      recognition.onerror = (event) => {
        console.error('Speech recognition error:', event.error);
        
        // Don't treat 'no-speech' or 'aborted' as fatal errors
        if (event.error === 'no-speech' || event.error === 'aborted') {
          // Auto-restart if we should still be listening
          if (shouldBeListeningRef.current) {
            restartTimeoutRef.current = window.setTimeout(() => {
              if (shouldBeListeningRef.current && recognitionRef.current) {
                try {
                  recognitionRef.current.start();
                } catch (e) {
                  console.log('Restart failed, will retry on next end event');
                }
              }
            }, 100);
          }
          return;
        }
        
        setState(prev => ({ 
          ...prev, 
          error: `Speech recognition error: ${event.error}`,
          isListening: false 
        }));
        shouldBeListeningRef.current = false;
      };

      recognition.onend = () => {
        console.log('Speech recognition ended, shouldBeListening:', shouldBeListeningRef.current);
        setState(prev => ({ ...prev, isListening: false }));
        
        // Auto-restart if we should still be listening
        if (shouldBeListeningRef.current) {
          restartTimeoutRef.current = window.setTimeout(() => {
            if (shouldBeListeningRef.current && recognitionRef.current) {
              try {
                console.log('Auto-restarting speech recognition');
                recognitionRef.current.start();
              } catch (e) {
                console.error('Failed to restart recognition:', e);
              }
            }
          }, 100);
        }
      };
    }

    return () => {
      shouldBeListeningRef.current = false;
      if (restartTimeoutRef.current) {
        clearTimeout(restartTimeoutRef.current);
      }
      if (recognitionRef.current) {
        recognitionRef.current.abort();
      }
      if (synthRef.current) {
        synthRef.current.cancel();
      }
    };
  }, []);

  const startListening = useCallback(() => {
    if (recognitionRef.current) {
      shouldBeListeningRef.current = true;
      try {
        recognitionRef.current.start();
        console.log('Started listening');
      } catch (e) {
        // Already started, that's fine
        console.log('Recognition already active');
      }
    }
  }, []);

  const stopListening = useCallback(() => {
    shouldBeListeningRef.current = false;
    if (restartTimeoutRef.current) {
      clearTimeout(restartTimeoutRef.current);
    }
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
        console.log('Stopped listening');
      } catch (e) {
        console.log('Recognition already stopped');
      }
    }
  }, []);

  const speak = useCallback(async (text: string): Promise<void> => {
    return new Promise((resolve, reject) => {
      if (!synthRef.current) {
        reject(new Error('Speech synthesis not supported'));
        return;
      }

      // Cancel any ongoing speech
      synthRef.current.cancel();

      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.9;
      utterance.pitch = 1;
      utterance.volume = 1;

      utterance.onstart = () => {
        setState(prev => ({ ...prev, isSpeaking: true }));
      };

      utterance.onend = () => {
        setState(prev => ({ ...prev, isSpeaking: false }));
        resolve();
      };

      utterance.onerror = (event) => {
        setState(prev => ({ ...prev, isSpeaking: false }));
        reject(new Error(`Speech synthesis error: ${event.error}`));
      };

      synthRef.current.speak(utterance);
    });
  }, []);

  const clearTranscript = useCallback(() => {
    setState(prev => ({ ...prev, transcript: '' }));
  }, []);

  return {
    ...state,
    startListening,
    stopListening,
    speak,
    clearTranscript,
  };
};
