// Fixed Interview Question Set as specified
// These questions are used for both text and voice interviews

export interface InterviewQuestion {
  id: string;
  text: string;
  category: 'basic' | 'technical' | 'hr';
  difficulty: 'easy' | 'medium' | 'hard';
  timeLimit: number; // in seconds
  optional?: boolean;
}

// 🟢 BASIC QUESTIONS
export const basicQuestions: InterviewQuestion[] = [
  {
    id: 'basic_1',
    text: 'Tell me about yourself.',
    category: 'basic',
    difficulty: 'easy',
    timeLimit: 120
  },
  {
    id: 'basic_2',
    text: 'What are your strengths?',
    category: 'basic',
    difficulty: 'easy',
    timeLimit: 120
  },
  {
    id: 'basic_3',
    text: 'Explain a challenging situation you handled.',
    category: 'basic',
    difficulty: 'medium',
    timeLimit: 150
  }
];

// 🔵 TECHNICAL QUESTIONS
export const technicalQuestions: InterviewQuestion[] = [
  {
    id: 'tech_1',
    text: 'Explain the concept of Object-Oriented Programming.',
    category: 'technical',
    difficulty: 'medium',
    timeLimit: 180
  },
  {
    id: 'tech_2',
    text: 'What is exception handling?',
    category: 'technical',
    difficulty: 'medium',
    timeLimit: 150
  },
  {
    id: 'tech_3',
    text: 'What is a class and an object?',
    category: 'technical',
    difficulty: 'easy',
    timeLimit: 120
  },
  // Optional questions based on difficulty
  {
    id: 'tech_4',
    text: 'What is inheritance?',
    category: 'technical',
    difficulty: 'medium',
    timeLimit: 120,
    optional: true
  },
  {
    id: 'tech_5',
    text: 'What is polymorphism?',
    category: 'technical',
    difficulty: 'medium',
    timeLimit: 120,
    optional: true
  },
  {
    id: 'tech_6',
    text: 'What is encapsulation?',
    category: 'technical',
    difficulty: 'medium',
    timeLimit: 120,
    optional: true
  },
  {
    id: 'tech_7',
    text: 'What is abstraction?',
    category: 'technical',
    difficulty: 'medium',
    timeLimit: 120,
    optional: true
  }
];

// 🟣 HR QUESTIONS
export const hrQuestions: InterviewQuestion[] = [
  {
    id: 'hr_1',
    text: 'Can you describe a project you are proud of?',
    category: 'hr',
    difficulty: 'medium',
    timeLimit: 180
  },
  {
    id: 'hr_2',
    text: 'What do you know about our company or this role?',
    category: 'hr',
    difficulty: 'medium',
    timeLimit: 150
  },
  {
    id: 'hr_3',
    text: 'Why should we hire you?',
    category: 'hr',
    difficulty: 'medium',
    timeLimit: 150
  },
  {
    id: 'hr_4',
    text: 'Where do you see yourself in the next 3–5 years?',
    category: 'hr',
    difficulty: 'easy',
    timeLimit: 120
  }
];

// Get all questions for an interview
export function getInterviewQuestions(
  interviewType: 'tech' | 'non-tech',
  includeDifficultQuestions: boolean = false
): InterviewQuestion[] {
  // Always start with basic questions
  const questions: InterviewQuestion[] = [...basicQuestions];
  
  // For tech interviews, include technical questions
  if (interviewType === 'tech') {
    const techQs = includeDifficultQuestions 
      ? technicalQuestions 
      : technicalQuestions.filter(q => !q.optional);
    questions.push(...techQs);
  }
  
  // Always include HR questions
  questions.push(...hrQuestions);
  
  return questions;
}

// Get question by ID
export function getQuestionById(id: string): InterviewQuestion | undefined {
  const allQuestions = [...basicQuestions, ...technicalQuestions, ...hrQuestions];
  return allQuestions.find(q => q.id === id);
}

// Get category display name
export function getCategoryDisplayName(category: string): string {
  switch (category) {
    case 'basic':
      return 'Basic';
    case 'technical':
      return 'Technical';
    case 'hr':
      return 'HR';
    default:
      return category;
  }
}

// Get category color classes
export function getCategoryColor(category: string): string {
  switch (category) {
    case 'basic':
      return 'bg-green-100 text-green-700';
    case 'technical':
      return 'bg-blue-100 text-blue-700';
    case 'hr':
      return 'bg-purple-100 text-purple-700';
    default:
      return 'bg-gray-100 text-gray-700';
  }
}
